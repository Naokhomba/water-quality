import React from 'react';
import { StateSummary } from '../../types';

interface HeatmapMatrixProps {
  states: StateSummary[];
  onSelectState: (state: string) => void;
}

export const HeatmapMatrix: React.FC<HeatmapMatrixProps> = ({ states, onSelectState }) => {
  const filteredStates = states.filter(s => s.totalObservations > 0).slice(0, 24);
  const parameters = ['BOD', 'DO', 'pH', 'Conductivity', 'Nitrate', 'FecalColiform'];

  const getCellColor = (param: string, val: number | undefined) => {
    if (val === undefined || val === null) return 'bg-slate-800 text-slate-500';

    if (param === 'BOD') {
      if (val <= 2) return 'bg-emerald-950 text-emerald-300 border-emerald-800';
      if (val <= 3) return 'bg-blue-950 text-blue-300 border-blue-800';
      if (val <= 6) return 'bg-amber-950 text-amber-300 border-amber-800';
      return 'bg-red-950 text-red-300 border-red-800';
    }

    if (param === 'DO') {
      if (val >= 6.5) return 'bg-emerald-950 text-emerald-300 border-emerald-800';
      if (val >= 5.0) return 'bg-blue-950 text-blue-300 border-blue-800';
      if (val >= 4.0) return 'bg-amber-950 text-amber-300 border-amber-800';
      return 'bg-red-950 text-red-300 border-red-800';
    }

    if (param === 'pH') {
      if (val >= 6.8 && val <= 8.2) return 'bg-emerald-950 text-emerald-300 border-emerald-800';
      if (val >= 6.5 && val <= 8.5) return 'bg-blue-950 text-blue-300 border-blue-800';
      return 'bg-amber-950 text-amber-300 border-amber-800';
    }

    return 'bg-slate-900 text-slate-300 border-slate-700';
  };

  return (
    <div className="w-full bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl overflow-x-auto">
      <div className="flex justify-between items-center mb-4">
        <div>
          <h3 className="text-base font-bold text-white">India Water Quality Heatmap Matrix</h3>
          <p className="text-xs text-slate-400">State vs Water Quality Parameter Matrix (Latest Reported Observations)</p>
        </div>
        <div className="flex items-center space-x-2 text-[10px]">
          <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 bg-emerald-700 rounded"></span><span>Good</span></span>
          <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 bg-blue-700 rounded"></span><span>Moderate</span></span>
          <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 bg-amber-700 rounded"></span><span>Stressed</span></span>
          <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 bg-red-700 rounded"></span><span>Critical</span></span>
        </div>
      </div>

      <table className="w-full text-xs text-left border-collapse">
        <thead>
          <tr className="border-b border-slate-800 text-slate-400 text-[11px] uppercase">
            <th className="py-2.5 px-3 font-semibold">State / Union Territory</th>
            <th className="py-2.5 px-3 font-semibold text-center">Stations</th>
            <th className="py-2.5 px-3 font-semibold text-center">BOD (mg/L)</th>
            <th className="py-2.5 px-3 font-semibold text-center">DO (mg/L)</th>
            <th className="py-2.5 px-3 font-semibold text-center">pH</th>
            <th className="py-2.5 px-3 font-semibold text-center">Cond (µmhos)</th>
            <th className="py-2.5 px-3 font-semibold text-center">Nitrate (mg/L)</th>
            <th className="py-2.5 px-3 font-semibold text-center">FC (MPN/100ml)</th>
            <th className="py-2.5 px-3 font-semibold text-center">WQI Indicator</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-800/60">
          {filteredStates.map(s => (
            <tr 
              key={s.state}
              onClick={() => onSelectState(s.state)}
              className="hover:bg-slate-800/50 cursor-pointer transition-colors"
            >
              <td className="py-2 px-3 font-medium text-white flex items-center space-x-1.5">
                <span>{s.state}</span>
                <span className="text-[10px] text-slate-500 font-normal">({s.code})</span>
              </td>
              <td className="py-2 px-3 text-center text-slate-400 font-mono text-[11px]">
                {s.stationCount}
              </td>
              {parameters.map(p => {
                const val = s.parameters[p]?.latest;
                const cellClass = getCellColor(p, val);
                return (
                  <td key={p} className="py-2 px-2 text-center">
                    <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-mono border ${cellClass}`}>
                      {val !== undefined ? val : '—'}
                    </span>
                  </td>
                );
              })}
              <td className="py-2 px-3 text-center">
                <span className={`font-bold text-[11px] px-2 py-0.5 rounded ${
                  (s.wqiScore ?? 0) >= 70 ? 'bg-emerald-950 text-emerald-300' :
                  (s.wqiScore ?? 0) >= 50 ? 'bg-amber-950 text-amber-300' :
                  'bg-red-950 text-red-300'
                }`}>
                  {s.wqiScore ? `${s.wqiScore}/100` : 'N/A'}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
