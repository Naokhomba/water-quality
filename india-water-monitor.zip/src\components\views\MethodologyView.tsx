import React from 'react';
import { BookOpen, Calculator, CheckCircle2, ShieldAlert, AlertCircle } from 'lucide-react';

export const MethodologyView: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-10 animate-fadeIn">
      {/* Header */}
      <div className="pb-4 border-b border-slate-800">
        <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight flex items-center space-x-2">
          <Calculator className="w-7 h-7 text-cyan-400" />
          <span>Scientific Methodology & Calculation Standards</span>
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Complete transparent documentation of data collection, validation, normalization, and indicator calculation
        </p>
      </div>

      {/* Section 1 */}
      <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-4">
        <h3 className="text-lg font-bold text-white flex items-center space-x-2">
          <span className="w-6 h-6 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 font-bold text-xs flex items-center justify-center">1</span>
          <span>Data Collection & Source Discovery</span>
        </h3>
        <div className="text-xs text-slate-300 leading-relaxed space-y-2">
          <p>
            The primary dataset-discovery directory for this application is <strong>Water Data Group</strong> (<a href="https://waterdatagroup.com" target="_blank" rel="noreferrer" className="text-cyan-400 underline">waterdatagroup.com</a>) via their public REST API:
          </p>
          <pre className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-cyan-300">
            GET https://waterdatagroup.com/api/v1/datasets.json
          </pre>
          <p>
            From the Water Data Group master index, datasets relevant to India, surface water quality, CPCB (Central Pollution Control Board), CWC (Central Water Commission), AI-KOSH, and India-WRIS were identified and prioritized. The application retrieves actual measurements from the underlying official government datasets and open repositories.
          </p>
        </div>
      </section>

      {/* Section 2 */}
      <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-4">
        <h3 className="text-lg font-bold text-white flex items-center space-x-2">
          <span className="w-6 h-6 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 font-bold text-xs flex items-center justify-center">2</span>
          <span>Data Validation & Normalization Schema</span>
        </h3>
        <div className="text-xs text-slate-300 leading-relaxed space-y-3">
          <p>
            Different historical reports use varying column nomenclatures. We map every record to a standardized internal schema:
          </p>
          <pre className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-slate-300 overflow-x-auto">
{`{
  "state": "Karnataka",
  "stateCode": "KA",
  "river": "Cauvery",
  "monitoringStation": "Cauvery at D/S of KRS Reservoir",
  "date": "2021-12-31",
  "year": 2021,
  "parameter": "BOD",
  "value": 2.4,
  "unit": "mg/L",
  "source": "CPCB NWMP",
  "agency": "Central Pollution Control Board",
  "sourceUrl": "https://cpcb.nic.in/nwmp-data/"
}`}
          </pre>
          <div className="p-3 bg-cyan-950/40 rounded-xl border border-cyan-800 text-cyan-200">
            <strong>Critical Authenticity Standard:</strong> No missing value is ever filled with zero. Missing measurements are strictly represented as <code className="text-cyan-300">null</code> and rendered as <em>“Data unavailable for this state/parameter.”</em>
          </div>
        </div>
      </section>

      {/* Section 3 */}
      <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-4">
        <h3 className="text-lg font-bold text-white flex items-center space-x-2">
          <span className="w-6 h-6 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 font-bold text-xs flex items-center justify-center">3</span>
          <span>Calculated Dashboard Water Quality Indicator</span>
        </h3>
        <div className="text-xs text-slate-300 leading-relaxed space-y-3">
          <p>
            The composite indicator is a weighted arithmetic index summarizing six foundational parameters:
          </p>
          <ul className="list-disc list-inside space-y-1.5 pl-2">
            <li><strong>Dissolved Oxygen (DO) (30% weight):</strong> Evaluated using a positive saturation curve where &ge; 6.5 mg/L scores 100 and &le; 1.0 mg/L scores 10.</li>
            <li><strong>Biochemical Oxygen Demand (BOD) (30% weight):</strong> Evaluated inversely where &le; 1.5 mg/L scores 100 and &ge; 12.0 mg/L scores 10.</li>
            <li><strong>pH (15% weight):</strong> Evaluated for neutral stability centered on pH 7.5; deviations &gt; 2.5 units are penalizing.</li>
            <li><strong>Electrical Conductivity (10% weight):</strong> Mineral and salt indicator where &le; 300 µmhos/cm scores 100.</li>
            <li><strong>Nitrate (10% weight):</strong> Nutrient load indicator where &le; 2.0 mg/L scores 100.</li>
            <li><strong>Fecal Coliform (5% weight):</strong> Pathogen indicator on a logarithmic normalization curve.</li>
          </ul>
        </div>
      </section>

      {/* Section 4 */}
      <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-4">
        <h3 className="text-lg font-bold text-rose-400 flex items-center space-x-2">
          <ShieldAlert className="w-6 h-6" />
          <span>Scientific Limitations & Interpretation Disclaimers</span>
        </h3>
        <div className="text-xs text-slate-300 leading-relaxed space-y-2">
          <ul className="list-disc list-inside space-y-1.5 pl-2 text-slate-300">
            <li><strong>Monitoring Density Variance:</strong> States with more industrial monitoring stations may exhibit higher average pollution values simply because their monitoring is focused on known degraded stretches.</li>
            <li><strong>Temporal Gaps:</strong> Manual sampling intervals vary across state pollution control boards from monthly to quarterly.</li>
            <li><strong>Designated Best Use:</strong> Official CPCB criteria vary depending on whether a river stretch is designated Class A, B, C, D, or E. A single numeric score is an educational proxy, not an official regulatory status.</li>
          </ul>
        </div>
      </section>
    </div>
  );
};
