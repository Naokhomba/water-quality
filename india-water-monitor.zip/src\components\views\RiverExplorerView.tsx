import React, { useState } from 'react';
import { RiverSummary } from '../../types';
import { TrendLineChart } from '../charts/TrendLineChart';
import { Compass, Search, MapPin, AlertCircle, Layers, Droplets, ExternalLink } from 'lucide-react';

interface RiverExplorerViewProps {
  rivers: RiverSummary[];
  selectedRiverName: string;
  onSelectRiverName: (name: string) => void;
}

export const RiverExplorerView: React.FC<RiverExplorerViewProps> = ({
  rivers,
  selectedRiverName,
  onSelectRiverName
}) => {
  const [search, setSearch] = useState('');
  const currentRiver = rivers.find(r => r.name.toLowerCase() === selectedRiverName.toLowerCase()) || rivers[0];

  const filteredRivers = rivers.filter(r => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return r.name.toLowerCase().includes(q) || r.statesCrossed.some(s => s.toLowerCase().includes(q));
  });

  // Prepare trend data
  const trendData = React.useMemo(() => {
    if (!currentRiver || !currentRiver.yearlyTrends) return [];
    return Object.keys(currentRiver.yearlyTrends)
      .sort((a, b) => parseInt(a) - parseInt(b))
      .map(yr => ({
        year: parseInt(yr),
        BOD: currentRiver.yearlyTrends[yr]?.BOD ?? null,
        DO: currentRiver.yearlyTrends[yr]?.DO ?? null
      }))
      .filter(d => d.BOD !== null || d.DO !== null);
  }, [currentRiver]);

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="pb-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center space-x-2">
            <Compass className="w-6 h-6 text-cyan-400" />
            <span>River Water Quality Explorer</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Basin intelligence, monitoring stations, and stretch-wise water quality for India's major rivers
          </p>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search river or state crossed..."
            className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* River Quick Selector Carousel */}
      <div className="flex space-x-2 overflow-x-auto pb-2 no-scrollbar">
        {filteredRivers.map(r => {
          const isSelected = r.name.toLowerCase() === currentRiver.name.toLowerCase();
          return (
            <button
              key={r.name}
              onClick={() => onSelectRiverName(r.name)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center space-x-1.5 ${
                isSelected
                  ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/30'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              <span>{r.name} River</span>
              <span className="text-[10px] opacity-75 font-mono">({r.stationCount} stns)</span>
            </button>
          );
        })}
      </div>

      {/* Selected River Detail Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl space-y-6">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 pb-6 border-b border-slate-800">
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <h3 className="text-2xl font-black text-white tracking-tight">{currentRiver.name} River</h3>
              <span className="text-xs bg-cyan-950 text-cyan-400 px-2.5 py-0.5 rounded-full border border-cyan-800 font-semibold">
                Major River Basin
              </span>
            </div>
            <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
              {currentRiver.description}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs bg-slate-950 p-4 rounded-xl border border-slate-800 flex-shrink-0">
            <div>
              <span className="text-slate-400 block text-[10px]">Length</span>
              <span className="text-white font-bold">{currentRiver.lengthKm.toLocaleString()} km</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">Basin Area</span>
              <span className="text-white font-bold">{currentRiver.basinAreaKm2.toLocaleString()} km²</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">Origin</span>
              <span className="text-white font-bold">{currentRiver.origin.split(',')[0]}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">Outflow</span>
              <span className="text-white font-bold">{currentRiver.outflow.split('(')[0]}</span>
            </div>
          </div>
        </div>

        {/* States Crossed */}
        <div>
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2">
            States Crossed ({currentRiver.statesCrossed.length}):
          </span>
          <div className="flex flex-wrap gap-1.5">
            {currentRiver.statesCrossed.map(st => (
              <span key={st} className="px-3 py-1 rounded-lg bg-slate-950 text-cyan-300 border border-slate-800 text-xs font-medium">
                {st}
              </span>
            ))}
          </div>
        </div>

        {/* River Parameters Metrics */}
        <div>
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-3">
            Latest Monitored River Water Quality:
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 text-xs block mb-1">BOD (mg/L)</span>
              <span className="text-xl font-bold text-cyan-300">
                {currentRiver.parameters['BOD']?.latest ?? 'N/A'}
              </span>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                Avg: {currentRiver.parameters['BOD']?.avg ?? 'N/A'} mg/L
              </span>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 text-xs block mb-1">DO (mg/L)</span>
              <span className="text-xl font-bold text-teal-300">
                {currentRiver.parameters['DO']?.latest ?? 'N/A'}
              </span>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                Avg: {currentRiver.parameters['DO']?.avg ?? 'N/A'} mg/L
              </span>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 text-xs block mb-1">pH</span>
              <span className="text-xl font-bold text-sky-300">
                {currentRiver.parameters['pH']?.latest ?? 'N/A'}
              </span>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                Target: 6.5 - 8.5
              </span>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 text-xs block mb-1">Stations Monitored</span>
              <span className="text-xl font-bold text-purple-300">
                {currentRiver.stationCount}
              </span>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                Observations: {currentRiver.totalObservations.toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Critical Polluted Stretches */}
        {currentRiver.criticalStretches && currentRiver.criticalStretches.length > 0 && (
          <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 text-xs space-y-2">
            <span className="font-semibold text-amber-400 flex items-center space-x-1.5">
              <AlertCircle className="w-4 h-4" />
              <span>Identified Stretches of Priority Surveillance (CPCB Criteria):</span>
            </span>
            <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
              {currentRiver.criticalStretches.map((str, idx) => (
                <li key={idx}>{str}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Historical Trend Chart */}
        {trendData.length > 0 && (
          <div className="pt-4 border-t border-slate-800">
            <TrendLineChart
              data={trendData}
              parameter="BOD"
              unit="mg/L"
              title={`${currentRiver.name} River — Historical BOD Trend`}
              sourceNote="Source: CPCB National Ganga / River Water Quality Monitoring Records"
            />
          </div>
        )}
      </div>
    </div>
  );
};
