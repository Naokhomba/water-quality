import React from 'react';
import { 
  Droplets, 
  Map, 
  GitCompare, 
  FileSpreadsheet, 
  Database, 
  ShieldCheck, 
  Layers, 
  Compass, 
  Activity, 
  ArrowRight,
  TrendingUp,
  AlertTriangle
} from 'lucide-react';
import { NationalKPIs, StateSummary, ActiveTab } from '../../types';
import { HeatmapMatrix } from '../charts/HeatmapMatrix';

interface HomeViewProps {
  kpis: NationalKPIs;
  states: StateSummary[];
  setActiveTab: (tab: ActiveTab) => void;
  onSelectState: (state: string) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  kpis,
  states,
  setActiveTab,
  onSelectState
}) => {
  return (
    <div className="space-y-12 animate-fadeIn">
      {/* Hero Section */}
      <section className="relative rounded-3xl overflow-hidden bg-gradient-to-b from-ocean-950 via-slate-900 to-slate-950 border border-slate-800 p-8 sm:p-14 shadow-2xl">
        {/* Subtle Water Waves in Background */}
        <div className="absolute inset-0 pointer-events-none opacity-25 overflow-hidden">
          <svg className="w-[200%] h-48 absolute bottom-0 wave-animation text-cyan-600/30" viewBox="0 0 1200 120" preserveAspectRatio="none">
            <path d="M0,0 C150,90 350,-40 500,60 C650,160 900,10 1200,40 L1200,120 L0,120 Z" fill="currentColor"></path>
          </svg>
        </div>

        <div className="relative z-10 max-w-3xl space-y-6">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-800/80 text-cyan-400 text-xs font-semibold tracking-wide uppercase shadow-sm">
            <Droplets className="w-3.5 h-3.5" />
            <span>National Environmental Intelligence Platform</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-tight">
            India Water Pollution & <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-teal-300">
              Water Quality Monitor
            </span>
          </h1>

          <p className="text-sm sm:text-base text-slate-300 font-normal leading-relaxed max-w-2xl">
            “Explore, Compare and Understand Water Quality Across India” — An open interactive portal synthesizing authentic water monitoring observations from CPCB, CWC, and national monitoring stations cataloged via Water Data Group.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-3 pt-2">
            <button
              onClick={() => setActiveTab('map')}
              className="flex items-center space-x-2 px-5 py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs transition-all shadow-lg shadow-cyan-600/25 transform hover:-translate-y-0.5"
            >
              <Map className="w-4 h-4" />
              <span>Explore India Map</span>
            </button>
            <button
              onClick={() => setActiveTab('compare')}
              className="flex items-center space-x-2 px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs transition-all hover:border-slate-600"
            >
              <GitCompare className="w-4 h-4" />
              <span>Compare States</span>
            </button>
            <button
              onClick={() => setActiveTab('explorer')}
              className="flex items-center space-x-2 px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs transition-all hover:border-slate-600"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>View Water Quality Data</span>
            </button>
            <button
              onClick={() => setActiveTab('sources')}
              className="flex items-center space-x-2 px-5 py-3 rounded-xl bg-teal-950/80 hover:bg-teal-900 text-teal-300 border border-teal-800 font-semibold text-xs transition-all"
            >
              <Database className="w-4 h-4" />
              <span>Explore Datasets</span>
            </button>
          </div>
        </div>
      </section>

      {/* National Summary Cards (Dynamically calculated) */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white tracking-tight flex items-center space-x-2">
            <Activity className="w-5 h-5 text-cyan-400" />
            <span>National Water Quality Indicators (Live Summary)</span>
          </h2>
          <span className="text-xs text-slate-400">
            Calculated dynamically from loaded dataset
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 sm:gap-4">
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-lg">
            <span className="text-[11px] text-slate-400 font-medium block mb-1">Total States/UTs</span>
            <span className="text-xl sm:text-2xl font-black text-white">{kpis.totalStatesUTs}</span>
            <span className="text-[10px] text-slate-500 block mt-1">28 States + 8 UTs</span>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-lg">
            <span className="text-[11px] text-slate-400 font-medium block mb-1">States With Data</span>
            <span className="text-xl sm:text-2xl font-black text-cyan-400">{kpis.statesWithData}</span>
            <span className="text-[10px] text-emerald-400 block mt-1">Publicly Monitored</span>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-lg">
            <span className="text-[11px] text-slate-400 font-medium block mb-1">Monitoring Stations</span>
            <span className="text-xl sm:text-2xl font-black text-teal-400">{kpis.totalMonitoringStations.toLocaleString()}</span>
            <span className="text-[10px] text-slate-500 block mt-1">NWMP Network</span>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-lg">
            <span className="text-[11px] text-slate-400 font-medium block mb-1">Water Bodies / Rivers</span>
            <span className="text-xl sm:text-2xl font-black text-sky-400">{kpis.waterBodiesRivers}+</span>
            <span className="text-[10px] text-slate-500 block mt-1">Major Basins & Lakes</span>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-lg">
            <span className="text-[11px] text-slate-400 font-medium block mb-1">Parameters Tracked</span>
            <span className="text-xl sm:text-2xl font-black text-amber-400">{kpis.parametersMonitored}</span>
            <span className="text-[10px] text-slate-500 block mt-1">BOD, DO, pH, FC, etc.</span>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-lg">
            <span className="text-[11px] text-slate-400 font-medium block mb-1">Total Records</span>
            <span className="text-xl sm:text-2xl font-black text-purple-400">{kpis.totalRecords.toLocaleString()}</span>
            <span className="text-[10px] text-slate-500 block mt-1">Normalized Samples</span>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-lg">
            <span className="text-[11px] text-slate-400 font-medium block mb-1">Data Catalog Sources</span>
            <span className="text-xl sm:text-2xl font-black text-blue-400">{kpis.dataSources}</span>
            <span className="text-[10px] text-slate-500 block mt-1">Water Data Group</span>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 shadow-lg">
            <span className="text-[11px] text-slate-400 font-medium block mb-1">Latest Data Year</span>
            <span className="text-xl sm:text-2xl font-black text-emerald-400">{kpis.latestDataYear}</span>
            <span className="text-[10px] text-slate-500 block mt-1">CPCB / NWDP</span>
          </div>
        </div>
      </section>

      {/* Feature Highlights Grid */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div 
          onClick={() => setActiveTab('map')}
          className="bg-slate-900/60 border border-slate-800 hover:border-cyan-700/60 rounded-2xl p-6 cursor-pointer transition-all hover:shadow-xl group"
        >
          <div className="w-10 h-10 rounded-xl bg-cyan-950 text-cyan-400 border border-cyan-800 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <Map className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">
            Interactive India Map
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed mb-4">
            Visual choropleth map across all 36 Indian states and UTs with parameter toggles for BOD, DO, pH, Conductivity, Nitrate, and calculated indicators.
          </p>
          <span className="text-xs text-cyan-400 font-semibold flex items-center space-x-1">
            <span>Explore Map</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </span>
        </div>

        <div 
          onClick={() => setActiveTab('rivers')}
          className="bg-slate-900/60 border border-slate-800 hover:border-teal-700/60 rounded-2xl p-6 cursor-pointer transition-all hover:shadow-xl group"
        >
          <div className="w-10 h-10 rounded-xl bg-teal-950 text-teal-400 border border-teal-800 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <Compass className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white mb-2 group-hover:text-teal-400 transition-colors">
            River Quality Explorer
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed mb-4">
            Explore major river basins: Ganga, Yamuna, Brahmaputra, Godavari, Krishna, Cauvery, Narmada, and monitoring stations along critical stretches.
          </p>
          <span className="text-xs text-teal-400 font-semibold flex items-center space-x-1">
            <span>Explore Rivers</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </span>
        </div>

        <div 
          onClick={() => setActiveTab('compare')}
          className="bg-slate-900/60 border border-slate-800 hover:border-blue-700/60 rounded-2xl p-6 cursor-pointer transition-all hover:shadow-xl group"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-950 text-blue-400 border border-blue-800 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <GitCompare className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white mb-2 group-hover:text-blue-400 transition-colors">
            State Comparison Engine
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed mb-4">
            Select up to 4 states side-by-side. Compare BOD, Dissolved Oxygen, pH, monitoring station counts, and longitudinal trend lines with scientific rigor.
          </p>
          <span className="text-xs text-blue-400 font-semibold flex items-center space-x-1">
            <span>Compare States</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </span>
        </div>
      </section>

      {/* Heatmap Matrix Section */}
      <section>
        <HeatmapMatrix states={states} onSelectState={onSelectState} />
      </section>
    </div>
  );
};
