import { 
  NormalizedWaterRecord, 
  StateSummary, 
  RiverSummary, 
  WaterDataGroupDataset, 
  ParameterInfo, 
  NationalKPIs,
  MonitoringStation 
} from '../types';

import waterSummaryData from '../data/waterSummary.json';
import statesMasterData from '../data/statesMaster.json';
import riversMasterData from '../data/riversMaster.json';
import parametersMasterData from '../data/parametersMaster.json';
import catalogData from '../data/waterDataGroupCatalog.json';
import stationsData from '../data/monitoringStations.json';

class WaterDataService {
  private summary = waterSummaryData;
  private states = statesMasterData as unknown as StateSummary[];
  private rivers = riversMasterData as unknown as RiverSummary[];
  private parameters = parametersMasterData as unknown as ParameterInfo[];
  private catalog = catalogData as unknown as WaterDataGroupDataset[];
  private stations = stationsData as unknown as MonitoringStation[];
  private fullRecordsCache: NormalizedWaterRecord[] | null = null;
  private isFetchingFull = false;

  public getNationalKPIs(): NationalKPIs {
    return this.summary.kpis;
  }

  public getAllStates(): StateSummary[] {
    return Object.values(this.summary.stateSummaries) as unknown as StateSummary[];
  }

  public getStateByName(name: string): StateSummary | undefined {
    return (this.summary.stateSummaries as any)[name];
  }

  public getAllRivers(): RiverSummary[] {
    return Object.values(this.summary.riverSummaries) as unknown as RiverSummary[];
  }

  public getRiverByName(name: string): RiverSummary | undefined {
    return (this.summary.riverSummaries as any)[name];
  }

  public getAllParameters(): ParameterInfo[] {
    return this.parameters;
  }

  public getParameterByCode(code: string): ParameterInfo | undefined {
    return this.parameters.find(p => p.code.toLowerCase() === code.toLowerCase());
  }

  public getAllStations(): MonitoringStation[] {
    return this.stations;
  }

  public getWaterDataGroupCatalog(): WaterDataGroupDataset[] {
    return this.catalog;
  }

  public getNationalTrends() {
    return this.summary.nationalTrends;
  }

  // Asynchronously load full records on demand for Data Explorer or CSV Export
  public async getFullObservations(): Promise<NormalizedWaterRecord[]> {
    if (this.fullRecordsCache) {
      return this.fullRecordsCache;
    }
    if (this.isFetchingFull) {
      await new Promise(r => setTimeout(r, 500));
      return this.getFullObservations();
    }
    this.isFetchingFull = true;
    try {
      const response = await fetch('/data/normalizedWaterData.json');
      if (!response.ok) {
        throw new Error('Failed to load full water quality records');
      }
      const data: NormalizedWaterRecord[] = await response.json();
      this.fullRecordsCache = data;
      return data;
    } catch (err) {
      console.warn('Could not load remote full dataset, using state aggregates:', err);
      return [];
    } finally {
      this.isFetchingFull = false;
    }
  }

  // Live query Water Data Group API to check freshness or fetch new datasets
  public async fetchLiveWaterDataGroupDirectory(): Promise<{ success: boolean; total?: number; message?: string }> {
    try {
      const res = await fetch('https://waterdatagroup.com/api/v1/datasets.json');
      if (!res.ok) throw new Error(`Status ${res.status}`);
      const json = await res.json();
      return { success: true, total: json.meta?.total || json.data?.length };
    } catch (e: any) {
      return { 
        success: false, 
        message: "Water Data Group data service is temporarily unavailable. Using cached directory catalog." 
      };
    }
  }
}

export const waterDataService = new WaterDataService();
