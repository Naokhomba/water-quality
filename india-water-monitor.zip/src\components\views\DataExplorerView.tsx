import React, { useState, useEffect } from 'react';
import { NormalizedWaterRecord } from '../../types';
import { waterDataService } from '../../services/waterDataService';
import { 
  FileSpreadsheet, 
  Download, 
  Search, 
  Filter, 
  RefreshCw, 
  ChevronLeft, 
  ChevronRight,
  ExternalLink
} from 'lucide-react';

export const DataExplorerView: React.FC = () => {
  const [records, setRecords] = useState<NormalizedWaterRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterState, setFilterState] = useState('ALL');
  const [filterParam, setFilterParam] = useState('ALL');
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 25;

  useEffect(() => {
    let isMounted = true;
    waterDataService.getFullObservations().then(data => {
      if (isMounted) {
        setRecords(data);
        setLoading(false);
      }
    });
    return () => { isMounted = false; };
  }, []);

  // Filter records
  const filtered = React.useMemo(() => {
    return records.filter(r => {
      if (filterState !== 'ALL' && r.state !== filterState) return false;
      if (filterParam !== 'ALL' && r.parameter !== filterParam) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        const mStation = r.monitoringStation?.toLowerCase().includes(q);
        const mRiver = r.river?.toLowerCase().includes(q);
        const mState = r.state.toLowerCase().includes(q);
        return mStation || mRiver || mState;
      }
      return true;
    });
  }, [records, filterState, filterParam, search]);

  const totalPages = Math.ceil(filtered.length / rowsPerPage) || 1;
  const paginatedRows = filtered.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage);

  // CSV Export
  const handleExportCSV = () => {
    if (filtered.length === 0) return;
    const headers = ['id', 'state', 'river', 'waterBody', 'monitoringStation', 'year', 'date', 'parameter', 'value', 'unit', 'agency', 'source', 'sourceUrl'];
    const csvRows = [headers.join(',')];

    filtered.forEach(r => {
      const row = [
        r.id,
        `"${r.state}"`,
        `"${r.river || ''}"`,
        `"${r.waterBody || ''}"`,
        `"${(r.monitoringStation || '').replace(/"/g, '""')}"`,
        r.year,
        r.date || '',
        r.parameter,
        r.value ?? '',
        `"${r.unit}"`,
        `"${r.agency}"`,
        `"${r.source}"`,
        `"${r.sourceUrl}"`
      ];
      csvRows.push(row.join(','));
    });

    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `india_water_quality_filtered_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // JSON Export
  const handleExportJSON = () => {
    if (filtered.length === 0) return;
    const blob = new Blob([JSON.stringify(filtered, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `india_water_quality_filtered_${Date.now()}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Unique state list
  const stateList = React.useMemo(() => {
    return Array.from(new Set(records.map(r => r.state))).sort();
  }, [records]);

  // Unique params list
  const paramList = React.useMemo(() => {
    return Array.from(new Set(records.map(r => r.parameter))).sort();
  }, [records]);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="pb-4 border-b border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center space-x-2">
            <FileSpreadsheet className="w-6 h-6 text-cyan-400" />
            <span>Water Quality Data Explorer & Downloads</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Search, filter, paginate, and download normalized public water quality records with complete provenance
          </p>
        </div>

        {/* Download Buttons */}
        <div className="flex items-center space-x-2">
          <button
            onClick={handleExportCSV}
            disabled={filtered.length === 0}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-semibold text-xs transition-colors shadow-md shadow-cyan-600/20"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download CSV ({filtered.length.toLocaleString()})</span>
          </button>
          <button
            onClick={handleExportJSON}
            disabled={filtered.length === 0}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-200 border border-slate-700 font-semibold text-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download JSON</span>
          </button>
        </div>
      </div>

      {/* Universal Filter Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Search station, river, or location..."
            className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <select
          value={filterState}
          onChange={(e) => {
            setFilterState(e.target.value);
            setCurrentPage(1);
          }}
          className="bg-slate-950 text-cyan-300 text-xs px-3 py-1.5 rounded-xl border border-slate-700 focus:outline-none focus:border-cyan-500"
        >
          <option value="ALL">All States ({stateList.length})</option>
          {stateList.map(s => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>

        <select
          value={filterParam}
          onChange={(e) => {
            setFilterParam(e.target.value);
            setCurrentPage(1);
          }}
          className="bg-slate-950 text-teal-300 text-xs px-3 py-1.5 rounded-xl border border-slate-700 focus:outline-none focus:border-teal-500"
        >
          <option value="ALL">All Parameters ({paramList.length})</option>
          {paramList.map(p => (
            <option key={p} value={p}>{p}</option>
          ))}
        </select>

        <span className="text-xs text-slate-400 font-mono ml-auto">
          {filtered.length.toLocaleString()} matching records
        </span>
      </div>

      {/* Table Container */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        {loading ? (
          <div className="p-16 text-center text-slate-400 text-xs flex flex-col items-center justify-center space-y-3">
            <RefreshCw className="w-6 h-6 text-cyan-400 animate-spin" />
            <span>Loading normalized observations...</span>
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-16 text-center text-slate-400 text-xs italic">
            “Data unavailable for this state/parameter.”
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-950 border-b border-slate-800 text-slate-400 text-[11px] uppercase">
                  <th className="py-3 px-4 font-semibold">Location / Station</th>
                  <th className="py-3 px-3 font-semibold">State</th>
                  <th className="py-3 px-3 font-semibold">River / Water Body</th>
                  <th className="py-3 px-3 font-semibold">Year</th>
                  <th className="py-3 px-3 font-semibold">Parameter</th>
                  <th className="py-3 px-3 font-semibold text-right">Value</th>
                  <th className="py-3 px-3 font-semibold">Unit</th>
                  <th className="py-3 px-4 font-semibold">Agency & Source</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {paginatedRows.map(r => (
                  <tr key={r.id} className="hover:bg-slate-800/50 transition-colors">
                    <td className="py-2.5 px-4 font-medium text-white max-w-xs truncate" title={r.monitoringStation}>
                      {r.monitoringStation}
                    </td>
                    <td className="py-2.5 px-3 text-slate-300 whitespace-nowrap">{r.state}</td>
                    <td className="py-2.5 px-3 text-cyan-400 whitespace-nowrap">
                      {r.river ? `${r.river} River` : (r.waterBody || 'Inland Waterbody')}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-400">{r.year}</td>
                    <td className="py-2.5 px-3 font-semibold text-white whitespace-nowrap">{r.parameter}</td>
                    <td className="py-2.5 px-3 font-mono font-bold text-cyan-300 text-right whitespace-nowrap">
                      {r.value !== null ? r.value : '—'}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-400 text-[11px] whitespace-nowrap">{r.unit}</td>
                    <td className="py-2.5 px-4 text-slate-400 text-[11px] whitespace-nowrap">
                      <a href={r.sourceUrl} target="_blank" rel="noreferrer" className="hover:text-cyan-300 flex items-center space-x-1">
                        <span>{r.agency}</span>
                        <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination Bar */}
        {!loading && filtered.length > 0 && (
          <div className="bg-slate-950 px-4 py-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <div>
              Showing {((currentPage - 1) * rowsPerPage) + 1} to {Math.min(currentPage * rowsPerPage, filtered.length)} of {filtered.length.toLocaleString()} entries
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:bg-slate-800 disabled:opacity-40 text-slate-300 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="text-slate-300 font-medium">
                Page {currentPage} of {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:bg-slate-800 disabled:opacity-40 text-slate-300 transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
