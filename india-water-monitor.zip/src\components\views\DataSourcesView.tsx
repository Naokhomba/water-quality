import React, { useState } from 'react';
import { WaterDataGroupDataset } from '../../types';
import { waterDataService } from '../../services/waterDataService';
import { Database, ExternalLink, Search, CheckCircle2, ShieldCheck } from 'lucide-react';

export const DataSourcesView: React.FC = () => {
  const catalog = waterDataService.getWaterDataGroupCatalog();
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('ALL');

  const categories = Array.from(new Set(catalog.map(c => c.category))).sort();

  const filtered = catalog.filter(c => {
    if (categoryFilter !== 'ALL' && c.category !== categoryFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return c.name.toLowerCase().includes(q) || c.description.toLowerCase().includes(q) || c.sourceAgency.toLowerCase().includes(q);
    }
    return true;
  });

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="pb-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center space-x-2">
            <Database className="w-6 h-6 text-cyan-400" />
            <span>Water Data Group Dataset Directory</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Dedicated India water-quality dataset catalogue discovered via the Water Data Group API ({catalog.length} cataloged datasets)
          </p>
        </div>

        <a
          href="https://waterdatagroup.com/api/v1/datasets.json"
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl bg-cyan-950 text-cyan-300 border border-cyan-800 text-xs font-semibold hover:bg-cyan-900 transition-colors self-start sm:self-auto"
        >
          <span>Live API Endpoint</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>

      {/* Primary Discovery Notice */}
      <div className="p-4 bg-cyan-950/40 border border-cyan-800/80 rounded-2xl text-xs text-cyan-200 leading-relaxed flex items-start space-x-3">
        <ShieldCheck className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
        <div>
          <span className="font-bold text-white block mb-0.5">Primary Discovery Directory: Water Data Group</span>
          Every dataset below has been discovered and categorized through the Water Data Group API directory (waterdatagroup.com). Click any card to access the original government portal or open repository.
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search datasets (e.g. CPCB, CWC, AI-KOSH, Groundwater)..."
            className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="bg-slate-900 text-cyan-300 text-xs px-3.5 py-2 rounded-xl border border-slate-700 focus:outline-none focus:border-cyan-500"
        >
          <option value="ALL">All Categories ({categories.length})</option>
          {categories.map(cat => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
      </div>

      {/* Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(d => (
          <div
            key={d.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between space-y-4 hover:border-slate-700 transition-colors"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] px-2 py-0.5 rounded font-semibold bg-slate-800 text-slate-300">
                  {d.category}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  Updated: {d.lastUpdated}
                </span>
              </div>

              <h4 className="font-bold text-white text-sm leading-snug">
                {d.name}
              </h4>

              <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed">
                {d.description}
              </p>
            </div>

            <div className="space-y-3 pt-3 border-t border-slate-800/80 text-[11px]">
              <div>
                <span className="text-slate-500 block text-[10px]">Data Types</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {d.dataTypes.slice(0, 3).map((dt, i) => (
                    <span key={i} className="px-2 py-0.5 rounded bg-slate-950 text-cyan-400 text-[10px]">
                      {dt}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-slate-400 font-medium">Access: {d.accessLevel}</span>
                <a
                  href={d.url}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center space-x-1 text-cyan-400 hover:text-cyan-300 font-semibold text-xs"
                >
                  <span>Open Portal</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
