import React, { useState } from 'react';
import { TrendLineChart } from '../charts/TrendLineChart';
import { Activity, Calendar, Droplets } from 'lucide-react';
import { waterDataService } from '../../services/waterDataService';

export const TrendsView: React.FC = () => {
  const nationalTrends = waterDataService.getNationalTrends();
  const [activeParam, setActiveParam] = useState<string>('BOD');

  const unitMap: Record<string, string> = {
    BOD: 'mg/L',
    DO: 'mg/L',
    pH: 'pH',
    Conductivity: 'µmhos/cm',
    Nitrate: 'mg/L',
    TotalColiform: 'MPN/100mL',
    FecalColiform: 'MPN/100mL',
    Temperature: '°C'
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      <div className="pb-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center space-x-2">
            <Activity className="w-6 h-6 text-cyan-400" />
            <span>National Longitudinal Water Quality Trends</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Historical time series across 2003–2025 derived from authentic annual monitoring records (no false interpolation)
          </p>
        </div>

        {/* Parameter Tabs */}
        <div className="flex flex-wrap gap-1.5 bg-slate-900 p-1.5 rounded-xl border border-slate-800">
          {Object.keys(unitMap).map(p => (
            <button
              key={p}
              onClick={() => setActiveParam(p)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                activeParam === p
                  ? 'bg-cyan-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Main Trend Line Chart */}
      <TrendLineChart
        data={nationalTrends}
        parameter={activeParam}
        unit={unitMap[activeParam] || ''}
        title={`National ${activeParam} Multi-Year Trend`}
        sourceNote="Source: Central Pollution Control Board (CPCB) National Water Quality Monitoring Programme"
      />

      {/* Observations Analysis Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4 text-xs text-slate-300">
        <h3 className="text-sm font-bold text-white">Historical Multi-Decadal Observations</h3>
        <p className="leading-relaxed">
          The national longitudinal dataset aggregates annual station observations reported by state pollution control boards to the CPCB under the National Water Quality Monitoring Programme. Parameters such as Biochemical Oxygen Demand (BOD) and Dissolved Oxygen (DO) highlight shifts in industrial treatment efficiency, municipal sewage loading, and seasonal monsoon flow variations across India.
        </p>
      </div>
    </div>
  );
};
