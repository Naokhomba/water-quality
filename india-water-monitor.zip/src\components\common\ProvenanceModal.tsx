import React from 'react';
import { X, ExternalLink, ShieldCheck, Database, Calendar, Tag, AlertTriangle } from 'lucide-react';

interface ProvenanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: {
    parameter: string;
    value: number | string | null;
    unit: string;
    state?: string;
    station?: string;
    river?: string | null;
    source: string;
    datasetName: string;
    agency: string;
    sourceUrl: string;
    date?: string;
    lastUpdated?: string;
    isCalculated?: boolean;
    calculationNote?: string;
  } | null;
}

export const ProvenanceModal: React.FC<ProvenanceModalProps> = ({ isOpen, onClose, data }) => {
  if (!isOpen || !data) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-2 text-cyan-400 mb-2">
          <ShieldCheck className="w-5 h-5" />
          <span className="text-xs font-semibold uppercase tracking-wider">Data Traceability & Provenance</span>
        </div>

        <h3 className="text-lg font-bold text-white mb-4">
          Measurement Provenance Details
        </h3>

        <div className="bg-slate-950/80 rounded-xl p-4 border border-slate-800 space-y-3 text-xs mb-4">
          <div className="flex justify-between items-center pb-2 border-b border-slate-800">
            <span className="text-slate-400">Parameter:</span>
            <span className="font-semibold text-white">{data.parameter}</span>
          </div>

          <div className="flex justify-between items-center pb-2 border-b border-slate-800">
            <span className="text-slate-400">Reported Value:</span>
            <span className="font-bold text-cyan-300 text-sm">
              {data.value !== null ? `${data.value} ${data.unit}` : 'Data Unavailable'}
            </span>
          </div>

          <div className="flex justify-between items-center pb-2 border-b border-slate-800">
            <span className="text-slate-400">Classification:</span>
            <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
              data.isCalculated 
                ? 'bg-amber-950 text-amber-300 border border-amber-800' 
                : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
            }`}>
              {data.isCalculated ? 'Calculated Dashboard Indicator' : 'Directly Reported Measurement'}
            </span>
          </div>

          {data.state && (
            <div className="flex justify-between items-center pb-2 border-b border-slate-800">
              <span className="text-slate-400">Location / State:</span>
              <span className="text-slate-200 font-medium">{data.state} {data.river ? `(${data.river} River)` : ''}</span>
            </div>
          )}

          {data.station && (
            <div className="flex justify-between items-start pb-2 border-b border-slate-800">
              <span className="text-slate-400">Monitoring Station:</span>
              <span className="text-slate-200 font-medium text-right max-w-xs">{data.station}</span>
            </div>
          )}

          <div className="flex justify-between items-center pb-2 border-b border-slate-800">
            <span className="text-slate-400">Original Agency:</span>
            <span className="text-slate-200 font-medium">{data.agency}</span>
          </div>

          <div className="flex justify-between items-center pb-2 border-b border-slate-800">
            <span className="text-slate-400">Dataset Source:</span>
            <span className="text-slate-200 font-medium">{data.datasetName}</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-slate-400">Discovery Directory:</span>
            <span className="text-cyan-400">Water Data Group API</span>
          </div>
        </div>

        {data.isCalculated && (
          <div className="p-3 bg-amber-950/30 border border-amber-800/60 rounded-xl text-amber-200/90 text-[11px] mb-4 flex items-start space-x-2">
            <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5 text-amber-400" />
            <span>
              {data.calculationNote || "This value is a dashboard-calculated composite indicator derived transparently from authentic observations and is not an official government index."}
            </span>
          </div>
        )}

        <div className="flex items-center justify-between">
          <a
            href={data.sourceUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs transition-colors"
          >
            <span>Open Original Dataset</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
