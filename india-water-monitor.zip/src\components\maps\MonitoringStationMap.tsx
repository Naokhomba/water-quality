import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { MonitoringStation } from '../../types';
import { MapPin, Search } from 'lucide-react';

interface MonitoringStationMapProps {
  stations: MonitoringStation[];
  onSelectStation?: (station: MonitoringStation) => void;
}

export const MonitoringStationMap: React.FC<MonitoringStationMapProps> = ({ stations, onSelectStation }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerGroupRef = useRef<L.LayerGroup | null>(null);

  const [filterState, setFilterState] = useState<string>('ALL');
  const [filterWaterBody, setFilterWaterBody] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Extract unique states & water types
  const uniqueStates = React.useMemo(() => {
    return Array.from(new Set(stations.map(s => s.state))).sort();
  }, [stations]);

  const uniqueTypes = React.useMemo(() => {
    return Array.from(new Set(stations.map(s => s.waterBodyType))).sort();
  }, [stations]);

  // Filter stations
  const filteredStations = React.useMemo(() => {
    return stations.filter(s => {
      if (filterState !== 'ALL' && s.state !== filterState) return false;
      if (filterWaterBody !== 'ALL' && s.waterBodyType !== filterWaterBody) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = s.name.toLowerCase().includes(q);
        const matchRiver = s.river?.toLowerCase().includes(q);
        const matchState = s.state.toLowerCase().includes(q);
        return matchName || matchRiver || matchState;
      }
      return true;
    });
  }, [stations, filterState, filterWaterBody, searchQuery]);

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [21.5, 79.5],
        zoom: 5,
        attributionControl: false
      });

      L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        subdomains: 'abcd',
        maxZoom: 19
      }).addTo(map);

      markerGroupRef.current = L.layerGroup().addTo(map);
      mapInstanceRef.current = map;
    }

    const markerGroup = markerGroupRef.current;
    if (!markerGroup) return;

    markerGroup.clearLayers();

    // Render markers (up to 300 visible markers for high rendering performance)
    const renderList = filteredStations.slice(0, 300);

    renderList.forEach(s => {
      const isRiver = s.waterBodyType === 'River' || Boolean(s.river);
      const color = isRiver ? '#0284c7' : '#14b8a6';

      const circleMarker = L.circleMarker([s.lat, s.lon], {
        radius: 6,
        fillColor: color,
        color: '#ffffff',
        weight: 1.5,
        opacity: 0.9,
        fillOpacity: 0.85
      });

      const popupHtml = `
        <div class="text-xs p-1">
          <div class="font-bold text-slate-100 text-sm mb-1">${s.name}</div>
          <div class="text-cyan-400 font-semibold mb-2">${s.state} ${s.river ? '• ' + s.river + ' River' : ''}</div>
          <div class="space-y-1 text-slate-300 text-[11px] mb-2">
            <div><span class="text-slate-400">Station Code:</span> ${s.code}</div>
            <div><span class="text-slate-400">Type:</span> ${s.waterBodyType}</div>
            <div><span class="text-slate-400">Coordinates:</span> ${s.lat.toFixed(3)}°N, ${s.lon.toFixed(3)}°E</div>
            <div><span class="text-slate-400">Monitoring Agency:</span> ${s.agency}</div>
          </div>
          <div class="text-[10px] text-slate-400 pt-1 border-t border-slate-700">
            Source: CPCB NWMP Public Monitoring Network
          </div>
        </div>
      `;

      circleMarker.bindPopup(popupHtml);
      circleMarker.on('click', () => {
        if (onSelectStation) onSelectStation(s);
      });

      circleMarker.addTo(markerGroup);
    });
  }, [filteredStations, onSelectStation]);

  return (
    <div className="relative w-full h-[600px] rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 shadow-2xl">
      <div ref={mapContainerRef} className="w-full h-full" />

      {/* Filter Control Bar */}
      <div className="absolute top-4 left-4 z-[400] flex flex-wrap items-center gap-2 bg-slate-900/90 backdrop-blur-md px-3.5 py-2.5 rounded-xl border border-slate-700 shadow-xl max-w-xl">
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search station or river..."
            className="bg-slate-950 border border-slate-700 rounded-lg pl-8 pr-2.5 py-1 text-xs text-slate-200 placeholder-slate-500 w-44 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <select
          value={filterState}
          onChange={(e) => setFilterState(e.target.value)}
          className="bg-slate-950 text-cyan-300 text-xs px-2.5 py-1 rounded-lg border border-slate-700 focus:outline-none focus:border-cyan-500"
        >
          <option value="ALL">All States ({stations.length})</option>
          {uniqueStates.map(st => (
            <option key={st} value={st}>{st}</option>
          ))}
        </select>

        <select
          value={filterWaterBody}
          onChange={(e) => setFilterWaterBody(e.target.value)}
          className="bg-slate-950 text-teal-300 text-xs px-2.5 py-1 rounded-lg border border-slate-700 focus:outline-none focus:border-teal-500"
        >
          <option value="ALL">All Water Types</option>
          {uniqueTypes.map(t => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>

        <span className="text-[11px] text-slate-400 font-medium ml-1">
          Showing {Math.min(filteredStations.length, 300)} of {filteredStations.length}
        </span>
      </div>

      {/* Map Legend */}
      <div className="absolute bottom-4 right-4 z-[400] bg-slate-900/90 backdrop-blur-md border border-slate-700 rounded-xl p-3 shadow-xl text-xs space-y-1.5">
        <div className="font-semibold text-slate-200 text-[11px]">Station Types</div>
        <div className="flex items-center space-x-2">
          <span className="w-3 h-3 rounded-full bg-sky-500 border border-white"></span>
          <span className="text-slate-300">River Monitoring Station</span>
        </div>
        <div className="flex items-center space-x-2">
          <span className="w-3 h-3 rounded-full bg-teal-500 border border-white"></span>
          <span className="text-slate-300">Lake / Reservoir / Tank</span>
        </div>
      </div>
    </div>
  );
};
