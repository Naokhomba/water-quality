import React from 'react';
import { X, Calculator, HelpCircle, CheckCircle2 } from 'lucide-react';

interface MethodologyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MethodologyModal: React.FC<MethodologyModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full max-h-[85vh] overflow-y-auto p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-2 text-cyan-400 mb-2">
          <Calculator className="w-5 h-5" />
          <span className="text-xs font-semibold uppercase tracking-wider">Methodology Explainer</span>
        </div>

        <h3 className="text-xl font-bold text-white mb-3">
          How is the Dashboard Water Quality Indicator Calculated?
        </h3>

        <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
          <p>
            The <strong>Dashboard Water Quality Indicator</strong> provides an intuitive, normalized score from <strong>0 (severely degraded)</strong> to <strong>100 (pristine/clean)</strong>. It is designed to summarize multiple water quality metrics into an understandable scale for research and public awareness.
          </p>

          <div className="p-3 bg-cyan-950/40 border border-cyan-800/60 rounded-xl text-cyan-200">
            <strong>Important Distinction:</strong> This indicator is created by this application. It does NOT replace official CPCB Designated Best Use classifications or state regulatory standards.
          </div>

          <h4 className="text-sm font-semibold text-white pt-2">1. Parameter Weighting</h4>
          <p>
            Key parameters are assigned scientific weights based on ecological and human health significance:
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <span className="text-white font-bold block">DO (Dissolved Oxygen)</span>
              <span className="text-cyan-400 font-semibold">Weight: 30%</span>
              <span className="text-[10px] text-slate-400 block">Higher is better (&gt;= 6 mg/L)</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <span className="text-white font-bold block">BOD</span>
              <span className="text-cyan-400 font-semibold">Weight: 30%</span>
              <span className="text-[10px] text-slate-400 block">Lower is better (&lt;= 3 mg/L)</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <span className="text-white font-bold block">pH (Acidity/Alkalinity)</span>
              <span className="text-cyan-400 font-semibold">Weight: 15%</span>
              <span className="text-[10px] text-slate-400 block">Optimal 6.5 - 8.5</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <span className="text-white font-bold block">Conductivity / Mineral</span>
              <span className="text-cyan-400 font-semibold">Weight: 10%</span>
              <span className="text-[10px] text-slate-400 block">Lower is better</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <span className="text-white font-bold block">Nitrate</span>
              <span className="text-cyan-400 font-semibold">Weight: 10%</span>
              <span className="text-[10px] text-slate-400 block">Lower is better (&lt;= 5 mg/L)</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <span className="text-white font-bold block">Fecal Coliform</span>
              <span className="text-cyan-400 font-semibold">Weight: 5%</span>
              <span className="text-[10px] text-slate-400 block">Microbial pathogen indicator</span>
            </div>
          </div>

          <h4 className="text-sm font-semibold text-white pt-2">2. Missing Value Policy</h4>
          <p>
            Unlike naive calculators, <strong>missing parameters are NEVER assigned a value of zero</strong> (which would falsely penalize a state). Instead, the score is calculated by re-normalizing across available parameters, and the UI reports an explicit <strong>Confidence / Data Availability Percentage</strong> (e.g. 85% coverage).
          </p>

          <h4 className="text-sm font-semibold text-white pt-2">3. Score Interpretation</h4>
          <div className="space-y-1.5">
            <div className="flex items-center space-x-2">
              <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
              <span className="text-emerald-400 font-semibold">80 - 100:</span>
              <span>Clean / Excellent water quality. Supports aquatic life and bathing.</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-3 h-3 rounded-full bg-blue-500"></span>
              <span className="text-blue-400 font-semibold">65 - 79:</span>
              <span>Good water quality. Minor stress; suitable with conventional treatment.</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-3 h-3 rounded-full bg-amber-500"></span>
              <span className="text-amber-400 font-semibold">45 - 64:</span>
              <span>Moderate / Stressed. Elevated BOD or low DO during non-monsoon months.</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-3 h-3 rounded-full bg-orange-500"></span>
              <span className="text-orange-400 font-semibold">25 - 44:</span>
              <span>Polluted. High organic/sewage load requiring urgent remediation.</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-3 h-3 rounded-full bg-red-500"></span>
              <span className="text-red-400 font-semibold">&lt; 25:</span>
              <span>Critically Polluted. Severe oxygen depletion and heavy bacterial contamination.</span>
            </div>
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition-colors"
          >
            Understood
          </button>
        </div>
      </div>
    </div>
  );
};
