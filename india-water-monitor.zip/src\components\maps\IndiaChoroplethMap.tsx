import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { StateSummary } from '../../types';
import { HelpCircle, Filter } from 'lucide-react';

interface IndiaChoroplethMapProps {
  states: StateSummary[];
  selectedState: string | null;
  onSelectState: (state: string) => void;
  onOpenMethodology: () => void;
}

export const IndiaChoroplethMap: React.FC<IndiaChoroplethMapProps> = ({
  states,
  selectedState,
  onSelectState,
  onOpenMethodology
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const geojsonLayerRef = useRef<L.GeoJSON | null>(null);

  const [selectedParam, setSelectedParam] = useState<'BOD' | 'DO' | 'pH' | 'Conductivity' | 'Nitrate' | 'WQI'>('BOD');
  const [hoveredState, setHoveredState] = useState<StateSummary | null>(null);

  // Helper map for O(1) state lookup
  const stateMap = React.useMemo(() => {
    const map = new Map<string, StateSummary>();
    states.forEach(s => {
      map.set(s.state.toLowerCase(), s);
    });
    return map;
  }, [states]);

  // Color calculation function
  const getColor = (summary: StateSummary | undefined) => {
    if (!summary || summary.dataStatus === 'No Data Available') {
      return '#334155'; // slate-700
    }

    if (selectedParam === 'WQI') {
      const score = summary.wqiScore;
      if (score === null) return '#334155';
      if (score >= 80) return '#10b981'; // emerald
      if (score >= 65) return '#0284c7'; // ocean blue
      if (score >= 45) return '#f59e0b'; // amber
      if (score >= 25) return '#f97316'; // orange
      return '#ef4444'; // red
    }

    const p = summary.parameters[selectedParam];
    if (!p || p.latest === null || p.latest === undefined) {
      return '#334155';
    }

    const val = p.latest;

    if (selectedParam === 'BOD') {
      // Lower is better. CPCB Bathing standard is <= 3 mg/L
      if (val <= 2.0) return '#10b981'; // clean
      if (val <= 3.0) return '#0284c7'; // bathing acceptable
      if (val <= 6.0) return '#f59e0b'; // moderate
      if (val <= 10.0) return '#f97316'; // high pollution
      return '#ef4444'; // critical pollution
    }

    if (selectedParam === 'DO') {
      // Higher is better. CPCB Bathing standard is >= 5 mg/L
      if (val >= 6.5) return '#10b981'; // excellent
      if (val >= 5.0) return '#0284c7'; // good
      if (val >= 4.0) return '#f59e0b'; // moderate stress
      if (val >= 2.5) return '#f97316'; // severe stress
      return '#ef4444'; // critical hypoxia
    }

    if (selectedParam === 'pH') {
      // Optimal 6.5 - 8.5
      if (val >= 6.8 && val <= 8.2) return '#10b981';
      if (val >= 6.5 && val <= 8.5) return '#0284c7';
      if (val >= 6.0 && val <= 9.0) return '#f59e0b';
      return '#ef4444';
    }

    if (selectedParam === 'Conductivity') {
      if (val <= 300) return '#10b981';
      if (val <= 800) return '#0284c7';
      if (val <= 1500) return '#f59e0b';
      return '#ef4444';
    }

    if (selectedParam === 'Nitrate') {
      if (val <= 2.0) return '#10b981';
      if (val <= 5.0) return '#0284c7';
      if (val <= 10.0) return '#f59e0b';
      return '#ef4444';
    }

    return '#0284c7';
  };

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [22.8, 80.5],
        zoom: 4.8,
        minZoom: 4,
        maxZoom: 9,
        zoomControl: true,
        attributionControl: false
      });

      // CartoDB Dark Matter base layer
      L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        subdomains: 'abcd',
        maxZoom: 19
      }).addTo(map);

      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;

    // Fetch India GeoJSON
    fetch('/india_states.geojson')
      .then(res => res.json())
      .then(geojsonData => {
        if (geojsonLayerRef.current) {
          map.removeLayer(geojsonLayerRef.current);
        }

        const layer = L.geoJSON(geojsonData, {
          style: (feature) => {
            const name = feature?.properties?.ST_NM || feature?.properties?.state_name || '';
            const summary = stateMap.get(name.toLowerCase());
            const isSelected = selectedState && summary?.state.toLowerCase() === selectedState.toLowerCase();

            return {
              fillColor: getColor(summary),
              weight: isSelected ? 3 : 1.2,
              opacity: 1,
              color: isSelected ? '#38bdf8' : '#1e293b',
              fillOpacity: isSelected ? 0.95 : 0.75
            };
          },
          onEachFeature: (feature, l) => {
            const name = feature?.properties?.ST_NM || feature?.properties?.state_name || '';
            const summary = stateMap.get(name.toLowerCase());

            l.on({
              mouseover: (e) => {
                const target = e.target;
                target.setStyle({
                  weight: 2.5,
                  color: '#38bdf8',
                  fillOpacity: 0.95
                });
                setHoveredState(summary || null);
              },
              mouseout: (e) => {
                if (geojsonLayerRef.current) {
                  geojsonLayerRef.current.resetStyle(e.target);
                }
                setHoveredState(null);
              },
              click: () => {
                if (summary) {
                  onSelectState(summary.state);
                }
              }
            });
          }
        }).addTo(map);

        geojsonLayerRef.current = layer;
      })
      .catch(err => {
        console.error('Failed to load India GeoJSON:', err);
      });

    return () => {
      // cleanup handled by ref
    };
  }, [stateMap, selectedParam, selectedState]);

  // Update styles when parameter or selected state changes
  useEffect(() => {
    if (geojsonLayerRef.current) {
      geojsonLayerRef.current.eachLayer((layer: any) => {
        const name = layer.feature?.properties?.ST_NM || layer.feature?.properties?.state_name || '';
        const summary = stateMap.get(name.toLowerCase());
        const isSelected = selectedState && summary?.state.toLowerCase() === selectedState.toLowerCase();

        layer.setStyle({
          fillColor: getColor(summary),
          weight: isSelected ? 3 : 1.2,
          color: isSelected ? '#38bdf8' : '#1e293b',
          fillOpacity: isSelected ? 0.95 : 0.75
        });
      });
    }
  }, [selectedParam, selectedState, stateMap]);

  return (
    <div className="relative w-full h-[620px] rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 shadow-2xl">
      {/* Map Container */}
      <div ref={mapContainerRef} className="w-full h-full" />

      {/* Top Controls Overlay */}
      <div className="absolute top-4 left-4 z-[400] flex flex-wrap items-center gap-2 bg-slate-900/90 backdrop-blur-md px-3.5 py-2 rounded-xl border border-slate-700 shadow-xl">
        <div className="flex items-center space-x-2 text-xs font-semibold text-slate-300">
          <Filter className="w-3.5 h-3.5 text-cyan-400" />
          <span>Map Parameter:</span>
        </div>
        <select
          value={selectedParam}
          onChange={(e: any) => setSelectedParam(e.target.value)}
          className="bg-slate-950 text-cyan-300 font-medium text-xs px-3 py-1.5 rounded-lg border border-slate-700 focus:outline-none focus:border-cyan-500"
        >
          <option value="BOD">Biochemical Oxygen Demand (BOD)</option>
          <option value="DO">Dissolved Oxygen (DO)</option>
          <option value="pH">pH (Acidity/Alkalinity)</option>
          <option value="Conductivity">Conductivity (µmhos/cm)</option>
          <option value="Nitrate">Nitrate (mg/L)</option>
          <option value="WQI">Calculated Water Quality Indicator</option>
        </select>

        {selectedParam === 'WQI' && (
          <button
            onClick={onOpenMethodology}
            className="flex items-center space-x-1 text-[11px] text-cyan-400 hover:text-cyan-300 bg-cyan-950/80 px-2.5 py-1 rounded-md border border-cyan-800"
          >
            <HelpCircle className="w-3 h-3" />
            <span>Methodology</span>
          </button>
        )}
      </div>

      {/* Hover State Card Overlay */}
      {hoveredState && (
        <div className="absolute top-4 right-4 z-[400] bg-slate-900/95 backdrop-blur-md border border-slate-700 rounded-xl p-3.5 shadow-2xl max-w-xs text-xs animate-fadeIn">
          <div className="flex justify-between items-start mb-1">
            <h4 className="font-bold text-white text-sm">{hoveredState.state}</h4>
            <span className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${
              hoveredState.dataStatus === 'Data Available' ? 'bg-emerald-950 text-emerald-300' :
              hoveredState.dataStatus === 'Limited Data' ? 'bg-amber-950 text-amber-300' :
              'bg-slate-800 text-slate-400'
            }`}>
              {hoveredState.dataStatus}
            </span>
          </div>

          <div className="text-[11px] text-slate-400 mb-2">
            Stations: {hoveredState.stationCount} • Records: {hoveredState.totalObservations.toLocaleString()}
          </div>

          {selectedParam === 'WQI' ? (
            <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Indicator Score:</span>
                <span className="font-bold text-cyan-300 text-sm">{hoveredState.wqiScore ?? 'N/A'}/100</span>
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">
                Confidence: {hoveredState.wqiConfidence}% parameter coverage
              </div>
            </div>
          ) : (
            <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">{selectedParam}:</span>
                <span className="font-bold text-cyan-300 text-sm">
                  {hoveredState.parameters[selectedParam]?.latest !== undefined 
                    ? `${hoveredState.parameters[selectedParam].latest} ${hoveredState.parameters[selectedParam].unit}`
                    : 'Data unavailable'}
                </span>
              </div>
              {hoveredState.parameters[selectedParam] && (
                <div className="flex justify-between text-[10px] text-slate-400 mt-1 pt-1 border-t border-slate-900">
                  <span>Avg: {hoveredState.parameters[selectedParam].avg}</span>
                  <span>Range: {hoveredState.parameters[selectedParam].min} - {hoveredState.parameters[selectedParam].max}</span>
                </div>
              )}
            </div>
          )}

          <div className="mt-2 text-[10px] text-cyan-400 text-right">
            Click state to explore full profile →
          </div>
        </div>
      )}

      {/* Legend Overlay */}
      <div className="absolute bottom-4 left-4 z-[400] bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-xl p-3 shadow-xl text-xs">
        <div className="font-semibold text-slate-200 text-[11px] mb-1.5">
          {selectedParam === 'WQI' ? 'Water Quality Indicator' :
           selectedParam === 'BOD' ? 'BOD (mg/L) — Lower is better' :
           selectedParam === 'DO' ? 'DO (mg/L) — Higher is better' :
           `${selectedParam} Quality Scale`}
        </div>
        <div className="space-y-1 text-[11px]">
          {selectedParam === 'BOD' && (
            <>
              <div className="flex items-center space-x-2"><span className="w-3 h-3 rounded bg-emerald-500"></span><span className="text-slate-300">&le; 2.0 (Pristine / Class A)</span></div>
              <div className="flex items-center space-x-2"><span className="w-3 h-3 rounded bg-sky-500"></span><span className="text-slate-300">2.1 - 3.0 (Bathing standard)</span></div>
              <div className="flex items-center space-x-2"><span className="w-3 h-3 rounded bg-amber-500"></span><span className="text-slate-300">3.1 - 6.0 (Moderate pollution)</span></div>
              <div className="flex items-center space-x-2"><span className="w-3 h-3 rounded bg-orange-500"></span><span className="text-slate-300">6.1 - 10.0 (High organic load)</span></div>
              <div className="flex items-center space-x-2"><span className="w-3 h-3 rounded bg-red-500"></span><span className="text-slate-300">&gt; 10.0 (Critically polluted)</span></div>
            </>
          )}
          {selectedParam === 'DO' && (
            <>
              <div className="flex items-center space-x-2"><span className="w-3 h-3 rounded bg-emerald-500"></span><span className="text-slate-300">&ge; 6.5 (High dissolved oxygen)</span></div>
              <div className="flex items-center space-x-2"><span className="w-3 h-3 rounded bg-sky-500"></span><span className="text-slate-300">5.0 - 6.4 (Bathing safe)</span></div>
              <div className="flex items-center space-x-2"><span className="w-3 h-3 rounded bg-amber-500"></span><span className="text-slate-300">4.0 - 4.9 (Stressed ecology)</span></div>
              <div className="flex items-center space-x-2"><span className="w-3 h-3 rounded bg-red-500"></span><span className="text-slate-300">&lt; 4.0 (Hypoxic / critical)</span></div>
            </>
          )}
          {selectedParam === 'WQI' && (
            <>
              <div className="flex items-center space-x-2"><span className="w-3 h-3 rounded bg-emerald-500"></span><span className="text-slate-300">80 - 100 (Clean / Excellent)</span></div>
              <div className="flex items-center space-x-2"><span className="w-3 h-3 rounded bg-sky-500"></span><span className="text-slate-300">65 - 79 (Good)</span></div>
              <div className="flex items-center space-x-2"><span className="w-3 h-3 rounded bg-amber-500"></span><span className="text-slate-300">45 - 64 (Moderate / Stressed)</span></div>
              <div className="flex items-center space-x-2"><span className="w-3 h-3 rounded bg-red-500"></span><span className="text-slate-300">&lt; 45 (Polluted)</span></div>
            </>
          )}
          <div className="flex items-center space-x-2 pt-1 border-t border-slate-800">
            <span className="w-3 h-3 rounded bg-slate-700"></span>
            <span className="text-slate-400">Data unavailable</span>
          </div>
        </div>
      </div>
    </div>
  );
};
