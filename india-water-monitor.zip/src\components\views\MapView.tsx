import React from 'react';
import { StateSummary } from '../../types';
import { IndiaChoroplethMap } from '../maps/IndiaChoroplethMap';
import { ArrowRight, Layers, Droplets, ShieldCheck, MapPin } from 'lucide-react';

interface MapViewProps {
  states: StateSummary[];
  selectedState: string | null;
  onSelectState: (state: string) => void;
  onOpenMethodology: () => void;
  onViewFullState: (state: string) => void;
}

export const MapView: React.FC<MapViewProps> = ({
  states,
  selectedState,
  onSelectState,
  onOpenMethodology,
  onViewFullState
}) => {
  const currentSummary = states.find(s => s.state.toLowerCase() === (selectedState || '').toLowerCase()) || null;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-2">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Interactive India Water Quality Map
          </h2>
          <p className="text-xs text-slate-400">
            Choropleth visualization across 36 Indian States and Union Territories with parameter toggles
          </p>
        </div>
        <div className="flex items-center space-x-2 text-xs text-slate-400">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>Click any state polygon to inspect profile</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Map Container */}
        <div className="lg:col-span-3">
          <IndiaChoroplethMap
            states={states}
            selectedState={selectedState}
            onSelectState={onSelectState}
            onOpenMethodology={onOpenMethodology}
          />
        </div>

        {/* Selected State Side Panel */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center space-x-2 text-cyan-400">
            <MapPin className="w-4 h-4" />
            <span className="text-xs font-semibold uppercase tracking-wider">State Detail Panel</span>
          </div>

          {currentSummary ? (
            <div className="space-y-4">
              <div className="pb-3 border-b border-slate-800">
                <h3 className="text-lg font-bold text-white">{currentSummary.state}</h3>
                <div className="text-xs text-slate-400 mt-0.5">
                  {currentSummary.type} • Capital: {currentSummary.capital}
                </div>
                <div className="mt-2 flex items-center space-x-2">
                  <span className={`text-[10px] px-2 py-0.5 rounded font-semibold ${
                    currentSummary.dataStatus === 'Data Available' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                    currentSummary.dataStatus === 'Limited Data' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                    'bg-slate-800 text-slate-400'
                  }`}>
                    {currentSummary.dataStatus}
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {currentSummary.stationCount} stations monitored
                  </span>
                </div>
              </div>

              {/* WQI Box */}
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs text-slate-400">Calculated Indicator:</span>
                  <span className="font-extrabold text-cyan-300 text-base">
                    {currentSummary.wqiScore !== null ? `${currentSummary.wqiScore}/100` : 'N/A'}
                  </span>
                </div>
                <div className="text-[10px] text-slate-500">
                  Data Confidence: {currentSummary.wqiConfidence}% parameter coverage
                </div>
              </div>

              {/* Key Parameters */}
              <div className="space-y-2">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                  Latest Monitored Values:
                </span>
                {Object.keys(currentSummary.parameters).length > 0 ? (
                  Object.keys(currentSummary.parameters).slice(0, 5).map(p => {
                    const item = currentSummary.parameters[p];
                    return (
                      <div key={p} className="flex justify-between items-center p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 text-xs">
                        <span className="font-semibold text-slate-300">{p}:</span>
                        <span className="font-mono text-cyan-300 font-medium">
                          {item.latest} {item.unit}
                        </span>
                      </div>
                    );
                  })
                ) : (
                  <div className="p-3 bg-slate-950 rounded-lg text-slate-500 text-xs italic text-center">
                    Data unavailable for this state.
                  </div>
                )}
              </div>

              {/* Rivers */}
              {currentSummary.rivers.length > 0 && (
                <div className="text-xs text-slate-400">
                  <span className="font-semibold text-slate-300 block mb-1">Major Rivers:</span>
                  <div className="flex flex-wrap gap-1">
                    {currentSummary.rivers.map(r => (
                      <span key={r} className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px]">
                        {r}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <button
                onClick={() => onViewFullState(currentSummary.state)}
                className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs transition-colors flex items-center justify-center space-x-1.5"
              >
                <span>View Complete State Profile</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <div className="p-6 text-center text-slate-500 text-xs space-y-2">
              <Layers className="w-8 h-8 mx-auto text-slate-600 opacity-50" />
              <p>Click any state polygon on the India map to display detailed water pollution indicators.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
