import React, { useState } from 'react';
import { ParameterInfo } from '../../types';
import { BookOpen, Search, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface ParametersViewProps {
  parameters: ParameterInfo[];
}

export const ParametersView: React.FC<ParametersViewProps> = ({ parameters }) => {
  const [search, setSearch] = useState('');
  const [selectedParamCode, setSelectedParamCode] = useState<string>(parameters[0]?.code || 'BOD');

  const filtered = parameters.filter(p => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return p.name.toLowerCase().includes(q) || p.code.toLowerCase().includes(q) || p.whyItMatters.toLowerCase().includes(q);
  });

  const activeParam = parameters.find(p => p.code === selectedParamCode) || parameters[0];

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="pb-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center space-x-2">
            <BookOpen className="w-6 h-6 text-cyan-400" />
            <span>Water Quality Parameters Guide & Standards</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Standard scientific definitions, units, environmental significance, and CPCB Designated Best Use standards
          </p>
        </div>

        <div className="w-full sm:w-64">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search parameter (e.g. BOD, DO)..."
            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* Main Detail Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Parameter List */}
        <div className="space-y-2">
          {filtered.map(p => {
            const isSelected = p.code === activeParam.code;
            return (
              <button
                key={p.code}
                onClick={() => setSelectedParamCode(p.code)}
                className={`w-full text-left p-4 rounded-xl border transition-all flex items-center justify-between ${
                  isSelected
                    ? 'bg-cyan-950/80 border-cyan-700 text-white shadow-lg'
                    : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:bg-slate-900 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="font-bold text-sm flex items-center space-x-2">
                    <span>{p.code}</span>
                    <span className="text-[10px] text-cyan-400 font-mono">({p.unit})</span>
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">{p.name}</div>
                </div>
                <span className="text-xs text-slate-500 font-mono">
                  {p.higherIsWorse ? 'Lower = Better' : 'Higher = Better'}
                </span>
              </button>
            );
          })}
        </div>

        {/* Right Column: Parameter Detail Card */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="pb-4 border-b border-slate-800 flex justify-between items-start">
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs px-2.5 py-1 rounded bg-cyan-950 text-cyan-400 font-bold border border-cyan-800">
                  {activeParam.code}
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-white">{activeParam.name}</h3>
              </div>
              <div className="text-xs text-slate-400 mt-1 font-mono">
                Standard Unit: <strong className="text-white">{activeParam.unit}</strong>
              </div>
            </div>
            <span className={`text-xs px-3 py-1 rounded-full font-semibold border ${
              activeParam.higherIsWorse 
                ? 'bg-rose-950 text-rose-300 border-rose-800' 
                : 'bg-emerald-950 text-emerald-300 border-emerald-800'
            }`}>
              {activeParam.higherIsWorse ? 'Higher = Greater Pollution' : 'Higher = Healthy Ecosystem'}
            </span>
          </div>

          <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
            <div>
              <h4 className="text-sm font-semibold text-white mb-1">Why it matters:</h4>
              <p className="p-3.5 bg-slate-950 rounded-xl border border-slate-800/80">
                {activeParam.whyItMatters}
              </p>
            </div>

            <div>
              <h4 className="text-sm font-semibold text-white mb-1">Typical Interpretation:</h4>
              <p className="p-3.5 bg-slate-950 rounded-xl border border-slate-800/80">
                {activeParam.interpretation}
              </p>
            </div>

            {/* Standards Table */}
            <div>
              <h4 className="text-sm font-semibold text-white mb-2">
                Official CPCB & WHO Water Quality Reference Standards:
              </h4>
              <div className="overflow-x-auto bg-slate-950 rounded-xl border border-slate-800">
                <table className="w-full text-xs text-left border-collapse">
                  <tbody className="divide-y divide-slate-800">
                    <tr>
                      <td className="py-2.5 px-3 font-semibold text-slate-300 w-1/2">
                        CPCB Class A (Drinking without treatment)
                      </td>
                      <td className="py-2.5 px-3 font-mono text-cyan-300 font-medium">{activeParam.cpcbClassA}</td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-semibold text-slate-300">
                        CPCB Class B (Outdoor bathing)
                      </td>
                      <td className="py-2.5 px-3 font-mono text-cyan-300 font-medium">{activeParam.cpcbClassB}</td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-semibold text-slate-300">
                        CPCB Class C (Drinking with conventional treatment)
                      </td>
                      <td className="py-2.5 px-3 font-mono text-cyan-300 font-medium">{activeParam.cpcbClassC}</td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 font-semibold text-slate-300">
                        WHO / BIS 10500 Guidelines
                      </td>
                      <td className="py-2.5 px-3 font-mono text-slate-300">{activeParam.whoStandard}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
