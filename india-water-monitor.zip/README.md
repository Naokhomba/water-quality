# India Water Pollution & Water Quality Monitor
> **“Explore, Compare and Understand Water Quality Across India”**

An interactive, scientific-grade web application and environmental intelligence dashboard tracking water pollution and water quality across all **36 Indian States and Union Territories**.

---

## 🌟 Key Features

- **Primary Dataset Discovery**: Powered by [Water Data Group](https://waterdatagroup.com/) via their REST API directory (`https://waterdatagroup.com/api/v1/datasets.json`), cataloging **597 India-related water and environmental datasets**.
- **Authentic Measurement Pipeline**: 26,626 normalized observations across 929 monitoring stations from the Central Pollution Control Board (CPCB) National Water Quality Monitoring Programme (NWMP). **Zero fabricated data**.
- **Interactive India Choropleth Map**: Dynamic parameter toggles (BOD, DO, pH, Conductivity, Nitrate, WQI) across all 36 States & UTs.
- **State Profiles**: In-depth state pages with station counts, parameter tables, and multi-year historical trends.
- **River Water Quality Explorer**: Comprehensive basin intelligence for major rivers (Ganga, Yamuna, Brahmaputra, Godavari, Krishna, Cauvery, Narmada, Tapi, Mahanadi, Sabarmati, Periyar, Zuari, Mandovi, Damodar, Subarnarekha).
- **Monitoring Station Map**: Geospatial visualization of 929 physical monitoring locations.
- **Multi-State Comparison**: Compare up to 4 states side-by-side with bar charts, matrices, and monitoring density caveats.
- **Data Explorer & Exporter**: Filter, search, and download filtered records as standardized `.csv` or `.json`.
- **AI Water Data Assistant**: Natural language query engine operating in **Strict Evidence Mode** with source citations and zero hallucinations.

---

## 🚀 Quick Start (Local)

### Option 1: Double-click `start.bat`
Simply double-click the `start.bat` file in this directory. It will configure the portable Node.js runtime and open `http://localhost:3000/` in your browser.

### Option 2: PowerShell
```powershell
cd C:\Users\Naokhomba\.gemini\antigravity\scratch\india-water-monitor
$env:Path = "C:\Users\Naokhomba\.node\node-v20.18.3-win-x64;$env:Path"
npm run dev -- --host 0.0.0.0 --port 3000
```

---

## 🌐 Public Internet Sharing

To generate a secure public HTTPS link accessible worldwide using Cloudflare:
```powershell
& "C:\Users\Naokhomba\.tools\cloudflared.exe" tunnel --url http://localhost:3000
```

---

## 📚 Data Provenance & Citations

- **Water Data Group Directory**: [waterdatagroup.com](https://waterdatagroup.com/)
- **Central Pollution Control Board (CPCB)**: [cpcb.nic.in](https://cpcb.nic.in/nwmp-data/)
- **Central Water Commission (CWC)**: [cwc.gov.in](https://cwc.gov.in/)
- **National Water Data Portal (NWDP)**: [nwdp.nwic.in](https://nwdp.nwic.in/)
- **AI-KOSH (IndiaAI)**: [aikosh.indiaai.gov.in](https://aikosh.indiaai.gov.in/)
