export interface NormalizedWaterRecord {
  id: string;
  state: string;
  stateCode?: string;
  district?: string;
  city?: string;
  river?: string | null;
  waterBody?: string;
  monitoringStation: string;
  stationCode?: string;
  latitude?: number;
  longitude?: number;
  date?: string;
  year: number;
  month?: number;
  parameter: string;
  parameterCode?: string;
  value: number | null;
  unit: string;
  minimum?: number | null;
  maximum?: number | null;
  source: string;
  sourceUrl: string;
  datasetName: string;
  datasetId?: string;
  agency: string;
  lastUpdated: string;
  isCalculated: boolean;
  waterType?: string;
}

export interface StateSummary {
  state: string;
  code: string;
  type: 'State' | 'Union Territory';
  capital: string;
  dataStatus: 'Data Available' | 'Limited Data' | 'No Data Available';
  totalObservations: number;
  stationCount: number;
  latestYear: number | null;
  parameters: Record<string, {
    latest: number;
    avg: number;
    min: number;
    max: number;
    count: number;
    unit: string;
    status: 'Good' | 'Moderate' | 'Critical' | 'High Pollution' | 'Abnormal';
  }>;
  rivers: string[];
  wqiScore: number | null;
  wqiConfidence: number;
  history: Record<string, Record<string, number>>;
}

export interface RiverSummary {
  name: string;
  lengthKm: number;
  basinAreaKm2: number;
  origin: string;
  outflow: string;
  statesCrossed: string[];
  description: string;
  criticalStretches: string[];
  totalObservations: number;
  stationCount: number;
  parameters: Record<string, {
    latest: number;
    avg: number;
    min: number;
    max: number;
    count: number;
    unit: string;
  }>;
  yearlyTrends: Record<string, Record<string, number>>;
}

export interface WaterDataGroupDataset {
  id: string;
  name: string;
  description: string;
  url: string;
  category: string;
  dataTypes: string[];
  accessLevel: string;
  region: string;
  country: string;
  coverage: string;
  lastUpdated: string;
  popular: boolean;
  sourceAgency: string;
  isWaterQualityFocus: boolean;
}

export interface ParameterInfo {
  code: string;
  name: string;
  unit: string;
  cpcbClassA: string;
  cpcbClassB: string;
  cpcbClassC: string;
  whoStandard: string;
  whyItMatters: string;
  interpretation: string;
  higherIsWorse: boolean;
  optimalMin: number;
  optimalMax: number;
  criticalThreshold: number;
}

export interface NationalKPIs {
  totalStatesUTs: number;
  statesWithData: number;
  totalMonitoringStations: number;
  waterBodiesRivers: number;
  parametersMonitored: number;
  totalRecords: number;
  dataSources: number;
  latestDataYear: number;
}

export interface MonitoringStation {
  code: string;
  name: string;
  state: string;
  river: string | null;
  waterBodyType: string;
  lat: number;
  lon: number;
  agency: string;
  years: number[];
}

export type ActiveTab = 
  | 'home'
  | 'map'
  | 'states'
  | 'rivers'
  | 'stations'
  | 'parameters'
  | 'compare'
  | 'trends'
  | 'hotspots'
  | 'explorer'
  | 'sources'
  | 'methodology'
  | 'about';
