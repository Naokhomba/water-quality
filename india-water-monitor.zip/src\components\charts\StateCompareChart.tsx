import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import { StateSummary } from '../../types';

interface StateCompareChartProps {
  states: StateSummary[];
  parameter: string;
  unit: string;
}

export const StateCompareChart: React.FC<StateCompareChartProps> = ({ states, parameter, unit }) => {
  const chartData = states.map(s => ({
    name: s.state,
    latest: s.parameters[parameter]?.latest ?? 0,
    average: s.parameters[parameter]?.avg ?? 0,
    stations: s.stationCount
  }));

  return (
    <div className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl">
      <div className="pb-3 border-b border-slate-800 mb-4 flex justify-between items-center">
        <div>
          <h4 className="font-bold text-white text-sm">{parameter} Multi-State Comparison</h4>
          <p className="text-xs text-slate-400">Comparing latest vs historical average ({unit})</p>
        </div>
        <span className="text-xs font-semibold text-cyan-400 bg-cyan-950 px-2.5 py-1 rounded-md border border-cyan-800">
          Unit: {unit}
        </span>
      </div>

      <div className="h-72 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
            <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} />
            <YAxis stroke="#64748b" fontSize={11} tickLine={false} unit={` ${unit}`} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#0f172a', 
                borderColor: '#334155', 
                borderRadius: '8px', 
                color: '#f8fafc',
                fontSize: '12px' 
              }} 
            />
            <Legend wrapperStyle={{ fontSize: '11px', color: '#94a3b8' }} />
            <Bar dataKey="latest" name={`Latest ${parameter}`} fill="#0ea5e9" radius={[4, 4, 0, 0]} />
            <Bar dataKey="average" name={`Historical Avg ${parameter}`} fill="#14b8a6" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] text-slate-400 mt-4 flex items-center justify-between">
        <span>* Higher reported values can correlate with higher monitoring density along urban stretches.</span>
        <span className="text-cyan-400">Source: CPCB NWMP</span>
      </div>
    </div>
  );
};
