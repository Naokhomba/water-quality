import React from 'react';
import { Droplets, ShieldCheck, Users, Globe, ExternalLink } from 'lucide-react';

export const AboutView: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-fadeIn">
      <div className="pb-4 border-b border-slate-800">
        <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight flex items-center space-x-2">
          <Droplets className="w-7 h-7 text-cyan-400" />
          <span>About the India Water Monitor Project</span>
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Explore, Compare and Understand Water Quality Across India
        </p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-5 text-xs text-slate-300 leading-relaxed">
        <p className="text-sm text-white font-medium">
          This platform provides an interactive visualization and exploration layer for publicly available water-quality datasets relating to India.
        </p>

        <p>
          The application aggregates and discovers datasets and does not replace official environmental monitoring agencies. Water Data Group (<a href="https://waterdatagroup.com" target="_blank" rel="noreferrer" className="text-cyan-400 underline">waterdatagroup.com</a>) serves as the primary dataset discovery directory.
        </p>

        <h3 className="text-sm font-bold text-white pt-2">Who is this platform built for?</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
            <span className="font-bold text-white block mb-1">Students & Academics</span>
            <p className="text-slate-400 text-[11px]">
              Civil and environmental engineering students researching water bodies, treatment plants, and river basins.
            </p>
          </div>
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
            <span className="font-bold text-white block mb-1">Journalists & Media</span>
            <p className="text-slate-400 text-[11px]">
              Data journalists investigating water pollution trends, river health, and state environmental performance.
            </p>
          </div>
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
            <span className="font-bold text-white block mb-1">Environmental Professionals</span>
            <p className="text-slate-400 text-[11px]">
              Hydrologists, policy analysts, and NGOs studying spatial variations in BOD, DO, and microbial contamination.
            </p>
          </div>
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
            <span className="font-bold text-white block mb-1">General Citizens</span>
            <p className="text-slate-400 text-[11px]">
              Public awareness on local river basins, lakes, drinking water sources, and state environmental indicators.
            </p>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-400">
          <span className="font-bold text-slate-300">Data Provenance Guarantee: </span>
          Every individual measurement displayed on this website is traceable to its original public government release. No synthetic values are generated.
        </div>
      </div>
    </div>
  );
};
