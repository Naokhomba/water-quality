import React from 'react';
import { MonitoringStation } from '../../types';
import { MonitoringStationMap } from '../maps/MonitoringStationMap';
import { SlidersHorizontal, MapPin, Database } from 'lucide-react';

interface StationsViewProps {
  stations: MonitoringStation[];
  onSelectStation?: (station: MonitoringStation) => void;
}

export const StationsView: React.FC<StationsViewProps> = ({ stations, onSelectStation }) => {
  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="pb-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center space-x-2">
            <SlidersHorizontal className="w-6 h-6 text-cyan-400" />
            <span>Monitoring Station Geospatial Explorer</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Explore 920+ physical monitoring stations across Indian rivers, lakes, and reservoirs under CPCB NWMP
          </p>
        </div>
        <div className="text-xs text-slate-400 flex items-center space-x-2">
          <Database className="w-4 h-4 text-cyan-400" />
          <span>Total Network: {stations.length} stations</span>
        </div>
      </div>

      <MonitoringStationMap
        stations={stations}
        onSelectStation={onSelectStation}
      />
    </div>
  );
};
