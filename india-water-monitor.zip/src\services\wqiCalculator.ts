export interface WQIResult {
  score: number;
  category: 'Clean / Excellent' | 'Good' | 'Moderate / Stressed' | 'Polluted' | 'Critically Polluted';
  color: string;
  confidence: number;
  availableParameters: string[];
  missingParameters: string[];
}

export function calculateDashboardWQI(parameters: Record<string, any>): WQIResult | null {
  const weights: Record<string, number> = {
    DO: 0.30,
    BOD: 0.30,
    pH: 0.15,
    Conductivity: 0.10,
    Nitrate: 0.10,
    FecalColiform: 0.05
  };

  let totalWeight = 0;
  let weightedSum = 0;
  const available: string[] = [];
  const missing: string[] = [];

  Object.keys(weights).forEach(param => {
    const pData = parameters[param];
    const val = pData?.latest ?? pData?.avg ?? null;

    if (val !== null && !isNaN(val)) {
      available.push(param);
      const subIndex = computeSubIndex(param, val);
      if (subIndex !== null) {
        weightedSum += subIndex * weights[param];
        totalWeight += weights[param];
      }
    } else {
      missing.push(param);
    }
  });

  if (totalWeight === 0) {
    return null;
  }

  const score = Math.round(weightedSum / totalWeight);
  const confidence = Math.round(totalWeight * 100);

  let category: WQIResult['category'] = 'Moderate / Stressed';
  let color = '#f59e0b'; // amber

  if (score >= 80) {
    category = 'Clean / Excellent';
    color = '#10b981'; // emerald
  } else if (score >= 65) {
    category = 'Good';
    color = '#3b82f6'; // blue
  } else if (score >= 45) {
    category = 'Moderate / Stressed';
    color = '#f59e0b'; // amber
  } else if (score >= 25) {
    category = 'Polluted';
    color = '#f97316'; // orange
  } else {
    category = 'Critically Polluted';
    color = '#ef4444'; // red
  }

  return {
    score,
    category,
    color,
    confidence,
    availableParameters: available,
    missingParameters: missing
  };
}

function computeSubIndex(param: string, val: number): number | null {
  if (val === null || isNaN(val)) return null;
  switch (param) {
    case 'DO':
      if (val >= 6.5) return 100;
      if (val <= 1.0) return 10;
      return Math.round(10 + (val - 1.0) * (90 / 5.5));
    case 'BOD':
      if (val <= 1.5) return 100;
      if (val >= 12.0) return 10;
      return Math.round(100 - (val - 1.5) * (90 / 10.5));
    case 'pH':
      const dev = Math.abs(val - 7.5);
      if (dev <= 0.5) return 100;
      if (dev >= 2.5) return 15;
      return Math.round(100 - (dev - 0.5) * (85 / 2.0));
    case 'Conductivity':
      if (val <= 300) return 100;
      if (val >= 2000) return 15;
      return Math.round(100 - (val - 300) * (85 / 1700));
    case 'Nitrate':
      if (val <= 2.0) return 100;
      if (val >= 20.0) return 15;
      return Math.round(100 - (val - 2.0) * (85 / 18.0));
    case 'FecalColiform':
      if (val <= 20) return 100;
      if (val >= 2500) return 10;
      return Math.round(100 - (Math.log10(val) - Math.log10(20)) * (90 / 2.1));
    default:
      return 70;
  }
}
