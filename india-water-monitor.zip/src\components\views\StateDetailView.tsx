import React, { useState } from 'react';
import { StateSummary } from '../../types';
import { TrendLineChart } from '../charts/TrendLineChart';
import { ProvenanceModal } from '../common/ProvenanceModal';
import { 
  Droplets, 
  MapPin, 
  Calendar, 
  ShieldCheck, 
  Layers, 
  Database, 
  ExternalLink,
  ChevronRight,
  SlidersHorizontal,
  Info
} from 'lucide-react';

interface StateDetailViewProps {
  states: StateSummary[];
  selectedStateName: string;
  onSelectStateName: (name: string) => void;
  onOpenMethodology: () => void;
}

export const StateDetailView: React.FC<StateDetailViewProps> = ({
  states,
  selectedStateName,
  onSelectStateName,
  onOpenMethodology
}) => {
  const currentState = states.find(s => s.state.toLowerCase() === selectedStateName.toLowerCase()) || states[0];
  const [selectedParamForTrend, setSelectedParamForTrend] = useState<string>('BOD');
  const [provenanceData, setProvenanceData] = useState<any | null>(null);

  // Prepare trend data for this state
  const trendData = React.useMemo(() => {
    if (!currentState || !currentState.history) return [];
    return Object.keys(currentState.history)
      .sort((a, b) => parseInt(a) - parseInt(b))
      .map(yr => ({
        year: parseInt(yr),
        [selectedParamForTrend]: currentState.history[yr]?.[selectedParamForTrend] ?? null
      }))
      .filter(d => d[selectedParamForTrend] !== null);
  }, [currentState, selectedParamForTrend]);

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* State Selector Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-950 text-cyan-400 border border-cyan-800 flex items-center justify-center font-bold text-sm">
            {currentState.code}
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              {currentState.state} Water Quality Profile
            </h2>
            <div className="text-xs text-slate-400 flex items-center space-x-2">
              <span>{currentState.type}</span>
              <span>•</span>
              <span>Capital: {currentState.capital}</span>
              <span>•</span>
              <span className={`font-semibold ${
                currentState.dataStatus === 'Data Available' ? 'text-emerald-400' :
                currentState.dataStatus === 'Limited Data' ? 'text-amber-400' : 'text-slate-500'
              }`}>
                {currentState.dataStatus}
              </span>
            </div>
          </div>
        </div>

        {/* State Dropdown Picker */}
        <div className="flex items-center space-x-2">
          <span className="text-xs text-slate-400 font-medium hidden sm:inline">Switch State:</span>
          <select
            value={currentState.state}
            onChange={(e) => onSelectStateName(e.target.value)}
            className="bg-slate-900 text-cyan-300 font-medium text-xs px-3.5 py-2 rounded-xl border border-slate-700 focus:outline-none focus:border-cyan-500 shadow-md"
          >
            {states.map(s => (
              <option key={s.state} value={s.state}>
                {s.state} ({s.code}) — {s.dataStatus}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg">
          <span className="text-xs text-slate-400 block mb-1">Monitoring Stations</span>
          <span className="text-2xl font-extrabold text-white">{currentState.stationCount}</span>
          <span className="text-[10px] text-slate-500 block mt-1">CPCB NWMP Network</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg">
          <span className="text-xs text-slate-400 block mb-1">Observations Monitored</span>
          <span className="text-2xl font-extrabold text-cyan-400">{currentState.totalObservations.toLocaleString()}</span>
          <span className="text-[10px] text-slate-500 block mt-1">Authentic Records</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg">
          <span className="text-xs text-slate-400 block mb-1">Latest Observation Year</span>
          <span className="text-2xl font-extrabold text-teal-400">{currentState.latestYear || 'N/A'}</span>
          <span className="text-[10px] text-slate-500 block mt-1">Most Recent Report</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-lg">
          <div className="flex justify-between items-start">
            <span className="text-xs text-slate-400 block mb-1">Calculated WQI</span>
            <button onClick={onOpenMethodology} className="text-slate-400 hover:text-cyan-400">
              <Info className="w-3.5 h-3.5" />
            </button>
          </div>
          <span className="text-2xl font-extrabold text-amber-400">
            {currentState.wqiScore !== null ? `${currentState.wqiScore}/100` : 'N/A'}
          </span>
          <span className="text-[10px] text-slate-500 block mt-1">
            Confidence: {currentState.wqiConfidence}%
          </span>
        </div>
      </div>

      {/* Water Quality Summary Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-800 gap-2">
          <div>
            <h3 className="text-base font-bold text-white">Water Quality Parameter Summary</h3>
            <p className="text-xs text-slate-400">Reported values, units, calculated status, and provenance</p>
          </div>
          <span className="text-xs text-cyan-400 bg-cyan-950/80 px-2.5 py-1 rounded-md border border-cyan-800 self-start sm:self-auto">
            Click any row to view provenance traceability
          </span>
        </div>

        {Object.keys(currentState.parameters).length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[11px] uppercase">
                  <th className="py-2.5 px-3">Parameter</th>
                  <th className="py-2.5 px-3">Latest Reported Value</th>
                  <th className="py-2.5 px-3">Unit</th>
                  <th className="py-2.5 px-3">Historical Range</th>
                  <th className="py-2.5 px-3">Observations</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {Object.keys(currentState.parameters).map(param => {
                  const item = currentState.parameters[param];
                  return (
                    <tr
                      key={param}
                      onClick={() => setProvenanceData({
                        parameter: param,
                        value: item.latest,
                        unit: item.unit,
                        state: currentState.state,
                        source: "CPCB National Water Quality Monitoring Programme",
                        datasetName: "Status of Water Quality in India",
                        agency: "Central Pollution Control Board",
                        sourceUrl: "https://cpcb.nic.in/nwmp-data/",
                        isCalculated: false
                      })}
                      className="hover:bg-slate-800/60 cursor-pointer transition-colors"
                    >
                      <td className="py-3 px-3 font-semibold text-white">{param}</td>
                      <td className="py-3 px-3 font-mono font-bold text-cyan-300 text-sm">
                        {item.latest}
                      </td>
                      <td className="py-3 px-3 text-slate-400 font-mono">{item.unit}</td>
                      <td className="py-3 px-3 text-slate-400 font-mono">
                        {item.min} - {item.max} (Avg: {item.avg})
                      </td>
                      <td className="py-3 px-3 text-slate-400 font-mono">{item.count}</td>
                      <td className="py-3 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          item.status === 'Good' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                          item.status === 'Moderate' ? 'bg-blue-950 text-blue-300 border border-blue-800' :
                          'bg-amber-950 text-amber-300 border border-amber-800'
                        }`}>
                          {item.status}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right text-cyan-400 hover:text-cyan-300">
                        View Traceability →
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-8 text-center text-slate-400 text-sm italic">
            “Data unavailable for this state/parameter.”
          </div>
        )}
      </div>

      {/* Historical Trend for State */}
      {trendData.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">Historical Multi-Year Trends for {currentState.state}</h3>
            <div className="flex items-center space-x-2">
              <span className="text-xs text-slate-400">Parameter:</span>
              <select
                value={selectedParamForTrend}
                onChange={(e) => setSelectedParamForTrend(e.target.value)}
                className="bg-slate-900 text-cyan-300 text-xs px-3 py-1.5 rounded-lg border border-slate-700"
              >
                {Object.keys(currentState.parameters).map(p => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
            </div>
          </div>

          <TrendLineChart
            data={trendData}
            parameter={selectedParamForTrend}
            unit={currentState.parameters[selectedParamForTrend]?.unit || ''}
            title={`${currentState.state} — ${selectedParamForTrend} Trend`}
            sourceNote="Source: CPCB NWMP Station Observations (no false interpolation)"
          />
        </div>
      )}

      {/* Provenance Modal Popup */}
      <ProvenanceModal
        isOpen={Boolean(provenanceData)}
        onClose={() => setProvenanceData(null)}
        data={provenanceData}
      />
    </div>
  );
};
