@echo off
title India Water Pollution & Water Quality Monitor
echo ========================================================
echo   INDIA WATER POLLUTION & WATER QUALITY MONITOR
echo   Explore, Compare and Understand Water Quality Across India
echo ========================================================
echo.
echo Starting local web server...
set "PATH=C:\Users\Naokhomba\.node\node-v20.18.3-win-x64;%PATH%"
cd /d "C:\Users\Naokhomba\.gemini\antigravity\scratch\india-water-monitor"
start http://localhost:3000/
npm run dev -- --host 0.0.0.0 --port 3000
pause
