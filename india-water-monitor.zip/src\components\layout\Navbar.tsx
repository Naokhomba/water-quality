import React, { useState } from 'react';
import { 
  Droplets, 
  Map, 
  Layers, 
  GitCompare, 
  Activity, 
  Flame, 
  FileSpreadsheet, 
  Database, 
  BookOpen, 
  Info, 
  Bot, 
  Search,
  SlidersHorizontal,
  Compass
} from 'lucide-react';
import { ActiveTab } from '../../types';
import { waterDataService } from '../../services/waterDataService';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenAssistant: () => void;
  onSelectState?: (state: string) => void;
  onSelectRiver?: (river: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  activeTab, 
  setActiveTab, 
  onOpenAssistant,
  onSelectState,
  onSelectRiver 
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<{ states: string[]; rivers: string[]; params: string[] } | null>(null);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const q = e.target.value;
    setSearchQuery(q);
    if (!q.trim() || q.length < 2) {
      setSearchResults(null);
      return;
    }

    const clean = q.toLowerCase();
    const states = waterDataService.getAllStates()
      .filter(s => s.state.toLowerCase().includes(clean))
      .map(s => s.state)
      .slice(0, 4);

    const rivers = waterDataService.getAllRivers()
      .filter(r => r.name.toLowerCase().includes(clean))
      .map(r => r.name)
      .slice(0, 4);

    const params = waterDataService.getAllParameters()
      .filter(p => p.code.toLowerCase().includes(clean) || p.name.toLowerCase().includes(clean))
      .map(p => p.name)
      .slice(0, 3);

    setSearchResults({ states, rivers, params });
  };

  const navItems: Array<{ id: ActiveTab; label: string; icon: React.ReactNode }> = [
    { id: 'home', label: 'Overview', icon: <Droplets className="w-4 h-4" /> },
    { id: 'map', label: 'India Map', icon: <Map className="w-4 h-4" /> },
    { id: 'states', label: 'States', icon: <Layers className="w-4 h-4" /> },
    { id: 'rivers', label: 'Rivers', icon: <Compass className="w-4 h-4" /> },
    { id: 'stations', label: 'Stations', icon: <SlidersHorizontal className="w-4 h-4" /> },
    { id: 'compare', label: 'Compare', icon: <GitCompare className="w-4 h-4" /> },
    { id: 'trends', label: 'Trends', icon: <Activity className="w-4 h-4" /> },
    { id: 'hotspots', label: 'Hotspots', icon: <Flame className="w-4 h-4" /> },
    { id: 'parameters', label: 'Parameters', icon: <BookOpen className="w-4 h-4" /> },
    { id: 'explorer', label: 'Data Table', icon: <FileSpreadsheet className="w-4 h-4" /> },
    { id: 'sources', label: 'Datasets', icon: <Database className="w-4 h-4" /> },
    { id: 'methodology', label: 'Methodology', icon: <Info className="w-4 h-4" /> },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-ocean-950 via-slate-900 to-teal-950 border-b border-slate-800/80 px-4 py-1.5 text-xs text-slate-400 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>Primary Discovery Directory: <a href="https://waterdatagroup.com" target="_blank" rel="noreferrer" className="text-cyan-400 hover:underline font-medium">Water Data Group</a></span>
          <span className="text-slate-600">|</span>
          <span>Official Monitoring: CPCB NWMP & NWDP Portals</span>
        </div>
        <div className="hidden md:flex items-center space-x-3 text-slate-400">
          <span>Standardized 26,000+ Observations across 36 States & UTs</span>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Tagline */}
          <div 
            onClick={() => setActiveTab('home')}
            className="flex items-center space-x-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 group-hover:scale-105 transition-transform">
              <Droplets className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="text-sm md:text-base font-bold text-white tracking-tight flex items-center space-x-1.5">
                <span>INDIA WATER MONITOR</span>
                <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800/50">LIVE</span>
              </div>
              <div className="text-[11px] text-slate-400 font-medium hidden sm:block">
                Explore, Compare and Understand Water Quality Across India
              </div>
            </div>
          </div>

          {/* Search Bar */}
          <div className="relative hidden lg:block w-72">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={handleSearchChange}
                placeholder="Search state, river, parameter..."
                className="w-full bg-slate-900 border border-slate-700/80 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500"
              />
            </div>

            {/* Autocomplete Dropdown */}
            {searchResults && (
              <div className="absolute left-0 right-0 top-full mt-1 bg-slate-900 border border-slate-700 rounded-lg shadow-2xl p-2 z-50 text-xs">
                {searchResults.states.length > 0 && (
                  <div className="mb-2">
                    <span className="text-[10px] uppercase font-semibold text-slate-400 px-2">States</span>
                    {searchResults.states.map(s => (
                      <button
                        key={s}
                        onClick={() => {
                          if (onSelectState) onSelectState(s);
                          setActiveTab('states');
                          setSearchResults(null);
                          setSearchQuery('');
                        }}
                        className="w-full text-left px-2 py-1.5 rounded hover:bg-cyan-950 text-slate-200 flex items-center justify-between"
                      >
                        <span>{s}</span>
                        <span className="text-[10px] text-cyan-400">View State →</span>
                      </button>
                    ))}
                  </div>
                )}
                {searchResults.rivers.length > 0 && (
                  <div className="mb-2">
                    <span className="text-[10px] uppercase font-semibold text-slate-400 px-2">Rivers</span>
                    {searchResults.rivers.map(r => (
                      <button
                        key={r}
                        onClick={() => {
                          if (onSelectRiver) onSelectRiver(r);
                          setActiveTab('rivers');
                          setSearchResults(null);
                          setSearchQuery('');
                        }}
                        className="w-full text-left px-2 py-1.5 rounded hover:bg-teal-950 text-slate-200 flex items-center justify-between"
                      >
                        <span>{r} River</span>
                        <span className="text-[10px] text-teal-400">View River →</span>
                      </button>
                    ))}
                  </div>
                )}
                {searchResults.params.length > 0 && (
                  <div>
                    <span className="text-[10px] uppercase font-semibold text-slate-400 px-2">Parameters</span>
                    {searchResults.params.map(p => (
                      <button
                        key={p}
                        onClick={() => {
                          setActiveTab('parameters');
                          setSearchResults(null);
                          setSearchQuery('');
                        }}
                        className="w-full text-left px-2 py-1.5 rounded hover:bg-slate-800 text-slate-200"
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* AI Assistant CTA Button */}
          <button
            onClick={onOpenAssistant}
            className="flex items-center space-x-2 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-cyan-600 to-teal-600 hover:from-cyan-500 hover:to-teal-500 text-white text-xs font-semibold shadow-md shadow-cyan-500/20 transition-all transform hover:-translate-y-0.5"
          >
            <Bot className="w-4 h-4 text-cyan-200 animate-pulse" />
            <span>Water Data AI</span>
          </button>
        </div>

        {/* Navigation Tabs Bar */}
        <nav className="flex space-x-1 overflow-x-auto py-2 border-t border-slate-800/80 no-scrollbar">
          {navItems.map(item => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                  isActive
                    ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-800/80 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
