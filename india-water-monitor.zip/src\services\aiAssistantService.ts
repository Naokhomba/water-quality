import { waterDataService } from './waterDataService';

export interface AIResponse {
  answer: string;
  citations: Array<{ source: string; dataset: string; url: string }>;
  suggestedQuestions?: string[];
  dataPoints?: Record<string, any>;
}

export function queryWaterDataAssistant(prompt: string): AIResponse {
  const query = prompt.toLowerCase().trim();
  const states = waterDataService.getAllStates();
  const rivers = waterDataService.getAllRivers();
  const params = waterDataService.getAllParameters();
  const kpis = waterDataService.getNationalKPIs();

  // 1. Definition / Explanation query: "What does BOD mean?", "What is DO?"
  for (const p of params) {
    if (
      query.includes(`what is ${p.code.toLowerCase()}`) ||
      query.includes(`what does ${p.code.toLowerCase()} mean`) ||
      query.includes(`explain ${p.code.toLowerCase()}`) ||
      query.includes(`meaning of ${p.code.toLowerCase()}`) ||
      query.includes(`what is ${p.name.toLowerCase()}`)
    ) {
      return {
        answer: `**${p.name} (${p.code})** is measured in **${p.unit}**.\n\n${p.whyItMatters}\n\n**Typical Interpretation**: ${p.interpretation}\n\n**CPCB Standards**:\n- Class A (Drinking without treatment): ${p.cpcbClassA}\n- Class B (Outdoor bathing): ${p.cpcbClassB}\n- Class C (Drinking with conventional treatment): ${p.cpcbClassC}`,
        citations: [
          {
            source: "Central Pollution Control Board (CPCB)",
            dataset: "Designated Best Use Water Quality Criteria",
            url: "https://cpcb.nic.in/nwmp-data/"
          },
          {
            source: "Water Data Group Directory",
            dataset: "CPCB National Water Quality Monitoring Programme",
            url: "https://waterdatagroup.com/api/v1/datasets.json"
          }
        ],
        suggestedQuestions: [
          `Which states have high ${p.code}?`,
          `What is the DO standard in India?`,
          `Show Karnataka ${p.code} data`
        ]
      };
    }
  }

  // 2. Highest / Worst BOD query: "Which states have highest BOD?"
  if (query.includes('highest bod') || query.includes('most polluted bod') || query.includes('worst bod')) {
    const sorted = states
      .filter(s => s.parameters['BOD'] && s.parameters['BOD'].avg > 0)
      .sort((a, b) => b.parameters['BOD'].avg - a.parameters['BOD'].avg)
      .slice(0, 5);

    const list = sorted.map((s, i) => `${i + 1}. **${s.state}**: Avg BOD = **${s.parameters['BOD'].avg} mg/L** (Latest = ${s.parameters['BOD'].latest} mg/L, Stations = ${s.stationCount})`).join('\n');

    return {
      answer: `Based on actual CPCB NWMP monitoring observations across Indian monitoring stations, the states with the highest reported average Biochemical Oxygen Demand (BOD) are:\n\n${list}\n\n*(Note: Higher reported values often reflect dense monitoring along known industrialized or urban river stretches and should not be equated to an official government ranking of overall state pollution.)*`,
      citations: [
        {
          source: "CPCB NWMP Annual Reports",
          dataset: "Inland Surface & River Water Quality",
          url: "https://cpcb.nic.in/nwmp-data/"
        },
        {
          source: "Water Data Group Directory",
          dataset: "AI-KOSH - Status of Water Quality in India",
          url: "https://aikosh.indiaai.gov.in/home/datasets/details/surface_water_quality.html"
        }
      ],
      suggestedQuestions: [
        "Which states have the lowest DO?",
        "Compare Karnataka and Kerala",
        "Show Ganga water quality"
      ]
    };
  }

  // 3. Lowest DO query: "Which states have lowest DO?"
  if (query.includes('lowest do') || query.includes('lowest dissolved oxygen')) {
    const sorted = states
      .filter(s => s.parameters['DO'] && s.parameters['DO'].avg > 0)
      .sort((a, b) => a.parameters['DO'].avg - b.parameters['DO'].avg)
      .slice(0, 5);

    const list = sorted.map((s, i) => `${i + 1}. **${s.state}**: Avg DO = **${s.parameters['DO'].avg} mg/L** (Latest = ${s.parameters['DO'].latest} mg/L)`).join('\n');

    return {
      answer: `Dissolved Oxygen (DO) supports aquatic biodiversity and self-purification. States with lower average recorded DO levels across monitored surface points include:\n\n${list}\n\nCPCB Class B outdoor bathing criteria requires DO >= 5.0 mg/L.`,
      citations: [
        {
          source: "CPCB NWMP",
          dataset: "Surface Water Quality Dataset",
          url: "https://cpcb.nic.in/nwmp-data/"
        }
      ]
    };
  }

  // 4. Comparison query: "Compare Kerala and Karnataka"
  const mentionedStates = states.filter(s => query.includes(s.state.toLowerCase()));
  if (mentionedStates.length >= 2) {
    const [s1, s2] = mentionedStates;
    const s1BOD = s1.parameters['BOD']?.latest ?? 'N/A';
    const s1DO = s1.parameters['DO']?.latest ?? 'N/A';
    const s1PH = s1.parameters['pH']?.latest ?? 'N/A';
    const s2BOD = s2.parameters['BOD']?.latest ?? 'N/A';
    const s2DO = s2.parameters['DO']?.latest ?? 'N/A';
    const s2PH = s2.parameters['pH']?.latest ?? 'N/A';

    return {
      answer: `### Comparison: **${s1.state}** vs **${s2.state}**\n\n| Parameter | ${s1.state} | ${s2.state} | CPCB Standard |\n|---|---|---|---|\n| **BOD** | ${s1BOD} mg/L | ${s2BOD} mg/L | < 3 mg/L (Bathing) |\n| **DO** | ${s1DO} mg/L | ${s2DO} mg/L | >= 5 mg/L (Bathing) |\n| **pH** | ${s1PH} | ${s2PH} | 6.5 - 8.5 |\n| **Monitoring Stations** | ${s1.stationCount} | ${s2.stationCount} | — |\n| **Calculated WQI** | ${s1.wqiScore ?? 'N/A'}/100 | ${s2.wqiScore ?? 'N/A'}/100 | Dashboard Indicator |\n\n**Data Freshness**: Observations recorded up to year ${s1.latestYear || s2.latestYear || 2025}.\n\n*Important: Differences in monitoring density (${s1.stationCount} vs ${s2.stationCount} stations) must be considered when evaluating environmental quality.*`,
      citations: [
        {
          source: "CPCB NWMP",
          dataset: "National Water Quality Monitoring Programme",
          url: "https://cpcb.nic.in/nwmp-data/"
        },
        {
          source: "Water Data Group Directory",
          dataset: "Water Data Group API",
          url: "https://waterdatagroup.com/api/v1/datasets.json"
        }
      ],
      suggestedQuestions: [
        `Show ${s1.state} river data`,
        `Show ${s2.state} historical trend`
      ]
    };
  }

  // 5. River query: "Show Ganga water quality", "Yamuna pollution"
  for (const r of rivers) {
    if (query.includes(r.name.toLowerCase())) {
      const pBOD = r.parameters['BOD']?.latest ?? 'N/A';
      const pDO = r.parameters['DO']?.latest ?? 'N/A';
      const pPH = r.parameters['pH']?.latest ?? 'N/A';
      const pFC = r.parameters['FecalColiform']?.latest ?? 'N/A';

      return {
        answer: `### **${r.name} River Water Quality Overview**\n\n${r.description}\n\n- **Origin**: ${r.origin}\n- **States Crossed**: ${r.statesCrossed.join(', ')}\n- **Length**: ${r.lengthKm.toLocaleString()} km | **Basin Area**: ${r.basinAreaKm2.toLocaleString()} sq km\n- **Monitoring Stations Monitored**: ${r.stationCount}\n\n**Latest Monitored Indicators**:\n- **BOD**: **${pBOD} mg/L**\n- **DO**: **${pDO} mg/L**\n- **pH**: **${pPH}**\n- **Fecal Coliform**: **${pFC} MPN/100mL**\n\n**Critical Stretches**: ${r.criticalStretches.join('; ')}.`,
        citations: [
          {
            source: "CPCB / NMCG / NWMP",
            dataset: "River Water Quality Monitoring",
            url: "https://cpcb.nic.in/nwmp-data/"
          },
          {
            source: "Water Data Group Directory",
            dataset: "AI-KOSH - Status of Water Quality in India",
            url: "https://aikosh.indiaai.gov.in/home/datasets/details/surface_water_quality.html"
          }
        ],
        suggestedQuestions: [
          `What states does ${r.name} cross?`,
          "Which rivers have the highest BOD?",
          "Show Yamuna water quality"
        ]
      };
    }
  }

  // 6. Specific State query: "Show me Karnataka water quality", "What about Maharashtra?"
  for (const s of states) {
    if (query.includes(s.state.toLowerCase())) {
      if (s.dataStatus === 'No Data Available') {
        return {
          answer: `**${s.state}**: No compatible water-quality data is currently available in the public CPCB / Water Data Group records loaded for this state/UT.\n\nCPCB and State PCB monitoring expansion is tracked through the National Water Data Portal and Water Data Group directory.`,
          citations: [
            {
              source: "Water Data Group Directory",
              dataset: "National Water Data Portal (NWDP)",
              url: "https://waterdatagroup.com/api/v1/datasets.json"
            }
          ]
        };
      }

      const pKeys = Object.keys(s.parameters);
      const rows = pKeys.map(k => {
        const item = s.parameters[k];
        return `| **${k}** | ${item.latest} ${item.unit} | ${item.avg} ${item.unit} | ${item.min} - ${item.max} | ${item.status} |`;
      }).join('\n');

      return {
        answer: `### **${s.state} Water Quality Profile**\n\n- **Type**: ${s.type} | **Capital**: ${s.capital}\n- **Data Coverage**: ${s.dataStatus} (${s.totalObservations.toLocaleString()} records across ${s.stationCount} stations)\n- **Latest Monitored Year**: ${s.latestYear || 2025}\n- **Dashboard WQI Indicator**: **${s.wqiScore ?? 'N/A'}/100** (${s.wqiConfidence}% parameter confidence)\n- **Key Water Bodies & Rivers**: ${s.rivers.join(', ') || 'Inland lakes & streams'}\n\n| Parameter | Latest Reported | Historical Avg | Range | Status |\n|---|---|---|---|---|\n${rows}\n\n*(Reported values derived directly from CPCB NWMP monitoring files.)*`,
        citations: [
          {
            source: "CPCB National Water Quality Monitoring Programme",
            dataset: "Status of Water Quality in India",
            url: "https://cpcb.nic.in/nwmp-data/"
          },
          {
            source: "Water Data Group",
            dataset: "AI-KOSH / CPCB Surface Water Quality",
            url: "https://waterdatagroup.com/api/v1/datasets.json"
          }
        ],
        suggestedQuestions: [
          `Compare ${s.state} with Kerala`,
          `What is the BOD in ${s.state}?`,
          "Which states have the highest BOD?"
        ]
      };
    }
  }

  // 7. National overview / summary
  if (query.includes('how many') || query.includes('total') || query.includes('overview') || query.includes('summary')) {
    return {
      answer: `### **National Water Monitoring Overview**\n\n- **Total States & UTs Tracked**: ${kpis.totalStatesUTs}\n- **States with Public Data Available**: ${kpis.statesWithData} of 36\n- **Monitoring Stations**: ${kpis.totalMonitoringStations.toLocaleString()} stations\n- **Water Bodies & Rivers**: ${kpis.waterBodiesRivers}+\n- **Parameters Monitored**: ${kpis.parametersMonitored} (including BOD, DO, pH, Conductivity, Nitrate, Coliforms, TDS)\n- **Total Normalized Observations**: ${kpis.totalRecords.toLocaleString()} records\n- **Data Catalog Source**: Water Data Group API (${kpis.dataSources} cataloged datasets)\n- **Latest Observation Period**: 2003 - ${kpis.latestDataYear}`,
      citations: [
        {
          source: "Water Data Group API",
          dataset: "Global Water Datasets Directory (India filter)",
          url: "https://waterdatagroup.com/api/v1/datasets.json"
        },
        {
          source: "CPCB NWMP",
          dataset: "National Water Quality Monitoring Programme",
          url: "https://cpcb.nic.in/nwmp-data/"
        }
      ]
    };
  }

  // 8. Fallback when data is absent (strictly avoiding hallucination)
  return {
    answer: "I don't have sufficient data to answer that from the available sources. I can answer questions regarding water quality parameters (BOD, DO, pH, coliforms, nitrates), CPCB standards, specific Indian states and UTs, major rivers (Ganga, Yamuna, Godavari, Krishna, Cauvery), and monitoring stations available in the Water Data Group directory and CPCB records.",
    citations: [
      {
        source: "Water Data Group",
        dataset: "Water Data Group Directory",
        url: "https://waterdatagroup.com/api/v1/datasets.json"
      }
    ],
    suggestedQuestions: [
      "Which states have the highest BOD?",
      "Show me Karnataka water quality",
      "What does BOD mean?",
      "Compare Kerala and Karnataka",
      "Show Ganga water quality"
    ]
  };
}
