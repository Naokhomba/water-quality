import React, { useState, useEffect } from 'react';
import { ActiveTab, StateSummary, RiverSummary, ParameterInfo, NationalKPIs, MonitoringStation } from './types';
import { waterDataService } from './services/waterDataService';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { HomeView } from './components/views/HomeView';
import { MapView } from './components/views/MapView';
import { StateDetailView } from './components/views/StateDetailView';
import { RiverExplorerView } from './components/views/RiverExplorerView';
import { StationsView } from './components/views/StationsView';
import { CompareView } from './components/views/CompareView';
import { TrendsView } from './components/views/TrendsView';
import { HotspotsView } from './components/views/HotspotsView';
import { ParametersView } from './components/views/ParametersView';
import { DataExplorerView } from './components/views/DataExplorerView';
import { DataSourcesView } from './components/views/DataSourcesView';
import { MethodologyView } from './components/views/MethodologyView';
import { AboutView } from './components/views/AboutView';
import { AIAssistantModal } from './components/views/AIAssistantModal';
import { MethodologyModal } from './components/common/MethodologyModal';

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [selectedState, setSelectedState] = useState<string>('Karnataka');
  const [selectedRiver, setSelectedRiver] = useState<string>('Ganga');
  const [isAssistantOpen, setIsAssistantOpen] = useState(false);
  const [isMethodologyOpen, setIsMethodologyOpen] = useState(false);

  const kpis = waterDataService.getNationalKPIs();
  const states = waterDataService.getAllStates();
  const rivers = waterDataService.getAllRivers();
  const parameters = waterDataService.getAllParameters();
  const stations = waterDataService.getAllStations();

  // Scroll to top on tab change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeTab]);

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      {/* Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAssistant={() => setIsAssistantOpen(true)}
        onSelectState={(st) => {
          setSelectedState(st);
          setActiveTab('states');
        }}
        onSelectRiver={(rv) => {
          setSelectedRiver(rv);
          setActiveTab('rivers');
        }}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'home' && (
          <HomeView
            kpis={kpis}
            states={states}
            setActiveTab={setActiveTab}
            onSelectState={(st) => {
              setSelectedState(st);
              setActiveTab('states');
            }}
          />
        )}

        {activeTab === 'map' && (
          <MapView
            states={states}
            selectedState={selectedState}
            onSelectState={(st) => setSelectedState(st)}
            onOpenMethodology={() => setIsMethodologyOpen(true)}
            onViewFullState={(st) => {
              setSelectedState(st);
              setActiveTab('states');
            }}
          />
        )}

        {activeTab === 'states' && (
          <StateDetailView
            states={states}
            selectedStateName={selectedState}
            onSelectStateName={setSelectedState}
            onOpenMethodology={() => setIsMethodologyOpen(true)}
          />
        )}

        {activeTab === 'rivers' && (
          <RiverExplorerView
            rivers={rivers}
            selectedRiverName={selectedRiver}
            onSelectRiverName={setSelectedRiver}
          />
        )}

        {activeTab === 'stations' && (
          <StationsView
            stations={stations}
          />
        )}

        {activeTab === 'compare' && (
          <CompareView
            states={states}
          />
        )}

        {activeTab === 'trends' && (
          <TrendsView />
        )}

        {activeTab === 'hotspots' && (
          <HotspotsView
            states={states}
            onSelectState={(st) => {
              setSelectedState(st);
              setActiveTab('states');
            }}
          />
        )}

        {activeTab === 'parameters' && (
          <ParametersView
            parameters={parameters}
          />
        )}

        {activeTab === 'explorer' && (
          <DataExplorerView />
        )}

        {activeTab === 'sources' && (
          <DataSourcesView />
        )}

        {activeTab === 'methodology' && (
          <MethodologyView />
        )}

        {activeTab === 'about' && (
          <AboutView />
        )}
      </main>

      {/* Footer */}
      <Footer setActiveTab={setActiveTab} />

      {/* Modals */}
      <AIAssistantModal
        isOpen={isAssistantOpen}
        onClose={() => setIsAssistantOpen(false)}
      />

      <MethodologyModal
        isOpen={isMethodologyOpen}
        onClose={() => setIsMethodologyOpen(false)}
      />
    </div>
  );
};

export default App;
