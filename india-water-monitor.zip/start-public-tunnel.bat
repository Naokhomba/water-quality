@echo off
title Cloudflare Public Tunnel - India Water Monitor
echo ========================================================
echo   Launching Public HTTPS Tunnel (trycloudflare.com)
echo ========================================================
echo.
"C:\Users\Naokhomba\.tools\cloudflared.exe" tunnel --url http://localhost:3000
pause
