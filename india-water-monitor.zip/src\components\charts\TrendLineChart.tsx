import React from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';

interface TrendLineChartProps {
  data: Array<Record<string, any>>;
  parameter: string;
  unit: string;
  title: string;
  sourceNote?: string;
}

export const TrendLineChart: React.FC<TrendLineChartProps> = ({
  data,
  parameter,
  unit,
  title,
  sourceNote = "Source: CPCB National Water Quality Monitoring Programme"
}) => {
  return (
    <div className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 mb-4 gap-2">
        <div>
          <h3 className="text-sm sm:text-base font-bold text-white">{title}</h3>
          <p className="text-xs text-slate-400">Longitudinal monitoring trends ({unit})</p>
        </div>
        <span className="text-[11px] bg-slate-800 text-slate-300 px-2.5 py-1 rounded-md self-start sm:self-auto">
          Unit: {unit}
        </span>
      </div>

      <div className="h-72 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 10, right: 20, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
            <XAxis 
              dataKey="year" 
              stroke="#64748b" 
              fontSize={11}
              tickLine={false} 
            />
            <YAxis 
              stroke="#64748b" 
              fontSize={11}
              tickLine={false}
              unit={` ${unit}`}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#0f172a', 
                borderColor: '#334155',
                borderRadius: '8px',
                color: '#f8fafc',
                fontSize: '12px'
              }}
              formatter={(val: any) => [`${val} ${unit}`, parameter]}
              labelFormatter={(label) => `Year: ${label}`}
            />
            <Legend 
              wrapperStyle={{ fontSize: '11px', color: '#94a3b8' }} 
            />
            <Line 
              type="monotone" 
              dataKey={parameter} 
              stroke="#0ea5e9" 
              strokeWidth={2.5} 
              dot={{ fill: '#38bdf8', r: 4 }}
              activeDot={{ r: 6 }}
              name={`Average ${parameter}`}
            />
            {data.some(d => d[`${parameter}_max`]) && (
              <Line 
                type="monotone" 
                dataKey={`${parameter}_max`} 
                stroke="#f43f5e" 
                strokeWidth={1.5} 
                strokeDasharray="4 4"
                dot={false}
                name={`Max Recorded ${parameter}`}
              />
            )}
            {data.some(d => d[`${parameter}_min`]) && (
              <Line 
                type="monotone" 
                dataKey={`${parameter}_min`} 
                stroke="#10b981" 
                strokeWidth={1.5} 
                strokeDasharray="4 4"
                dot={false}
                name={`Min Recorded ${parameter}`}
              />
            )}
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="text-[10px] text-slate-500 mt-2 text-right">
        {sourceNote}
      </div>
    </div>
  );
};
