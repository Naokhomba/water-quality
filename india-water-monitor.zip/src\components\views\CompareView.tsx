import React, { useState } from 'react';
import { StateSummary } from '../../types';
import { StateCompareChart } from '../charts/StateCompareChart';
import { GitCompare, Plus, X, AlertCircle } from 'lucide-react';

interface CompareViewProps {
  states: StateSummary[];
}

export const CompareView: React.FC<CompareViewProps> = ({ states }) => {
  // Up to 4 states
  const [selectedStateNames, setSelectedStateNames] = useState<string[]>([
    'Karnataka', 'Kerala', 'Maharashtra'
  ]);
  const [activeParam, setActiveParam] = useState<'BOD' | 'DO' | 'pH' | 'Conductivity'>('BOD');

  const availableStates = states.filter(s => s.totalObservations > 0);
  const selectedStateSummaries = selectedStateNames
    .map(name => states.find(s => s.state.toLowerCase() === name.toLowerCase()))
    .filter(Boolean) as StateSummary[];

  const handleAddState = (name: string) => {
    if (selectedStateNames.length < 4 && !selectedStateNames.includes(name)) {
      setSelectedStateNames([...selectedStateNames, name]);
    }
  };

  const handleRemoveState = (name: string) => {
    setSelectedStateNames(selectedStateNames.filter(n => n !== name));
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="pb-4 border-b border-slate-800">
        <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center space-x-2">
          <GitCompare className="w-6 h-6 text-cyan-400" />
          <span>Compare Indian States & Union Territories</span>
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Side-by-side comparative analysis of water quality parameters, monitoring station coverage, and calculated indicators (Select up to 4 states).
        </p>
      </div>

      {/* State Selector Chips */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-slate-300 mr-2">Selected States:</span>
          {selectedStateNames.map(name => (
            <span
              key={name}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-cyan-950 text-cyan-300 border border-cyan-800 text-xs font-medium"
            >
              <span>{name}</span>
              {selectedStateNames.length > 1 && (
                <button
                  onClick={() => handleRemoveState(name)}
                  className="p-0.5 hover:bg-cyan-900 rounded text-cyan-400 hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </span>
          ))}

          {selectedStateNames.length < 4 && (
            <select
              onChange={(e) => {
                if (e.target.value) {
                  handleAddState(e.target.value);
                  e.target.value = '';
                }
              }}
              defaultValue=""
              className="bg-slate-950 text-slate-300 text-xs px-3 py-1.5 rounded-lg border border-slate-700 focus:outline-none focus:border-cyan-500"
            >
              <option value="" disabled>+ Add State (up to 4)</option>
              {availableStates
                .filter(s => !selectedStateNames.includes(s.state))
                .map(s => (
                  <option key={s.state} value={s.state}>{s.state}</option>
                ))}
            </select>
          )}
        </div>

        {/* Parameter Tabs */}
        <div className="flex items-center space-x-2 pt-2 border-t border-slate-800">
          <span className="text-xs text-slate-400 mr-2">Comparison Metric:</span>
          {(['BOD', 'DO', 'pH', 'Conductivity'] as const).map(p => (
            <button
              key={p}
              onClick={() => setActiveParam(p)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                activeParam === p
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Main Bar Chart */}
      <StateCompareChart
        states={selectedStateSummaries}
        parameter={activeParam}
        unit={activeParam === 'Conductivity' ? 'µmhos/cm' : (activeParam === 'pH' ? 'pH' : 'mg/L')}
      />

      {/* Side-by-side Metric Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl overflow-x-auto">
        <h3 className="text-sm font-bold text-white mb-3">Direct Metric Comparison Matrix</h3>
        <table className="w-full text-xs text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400 text-[11px] uppercase">
              <th className="py-2.5 px-3">Metric</th>
              {selectedStateSummaries.map(s => (
                <th key={s.state} className="py-2.5 px-3 font-semibold text-white">{s.state}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            <tr>
              <td className="py-2.5 px-3 font-medium text-slate-300">Total Monitoring Stations</td>
              {selectedStateSummaries.map(s => (
                <td key={s.state} className="py-2.5 px-3 font-mono text-cyan-300 font-bold">{s.stationCount}</td>
              ))}
            </tr>
            <tr>
              <td className="py-2.5 px-3 font-medium text-slate-300">Total Observations</td>
              {selectedStateSummaries.map(s => (
                <td key={s.state} className="py-2.5 px-3 font-mono text-slate-300">{s.totalObservations.toLocaleString()}</td>
              ))}
            </tr>
            <tr>
              <td className="py-2.5 px-3 font-medium text-slate-300">Latest BOD (mg/L)</td>
              {selectedStateSummaries.map(s => (
                <td key={s.state} className="py-2.5 px-3 font-mono font-bold text-white">
                  {s.parameters['BOD']?.latest ?? 'N/A'}
                </td>
              ))}
            </tr>
            <tr>
              <td className="py-2.5 px-3 font-medium text-slate-300">Latest DO (mg/L)</td>
              {selectedStateSummaries.map(s => (
                <td key={s.state} className="py-2.5 px-3 font-mono font-bold text-white">
                  {s.parameters['DO']?.latest ?? 'N/A'}
                </td>
              ))}
            </tr>
            <tr>
              <td className="py-2.5 px-3 font-medium text-slate-300">Latest pH</td>
              {selectedStateSummaries.map(s => (
                <td key={s.state} className="py-2.5 px-3 font-mono text-slate-300">
                  {s.parameters['pH']?.latest ?? 'N/A'}
                </td>
              ))}
            </tr>
            <tr>
              <td className="py-2.5 px-3 font-medium text-slate-300">Calculated WQI Score</td>
              {selectedStateSummaries.map(s => (
                <td key={s.state} className="py-2.5 px-3 font-mono font-bold text-amber-400">
                  {s.wqiScore !== null ? `${s.wqiScore}/100` : 'N/A'}
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>

      {/* Critical Methodological Note */}
      <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl text-xs text-slate-400 space-y-1.5">
        <div className="flex items-center space-x-2 text-cyan-400 font-semibold">
          <AlertCircle className="w-4 h-4" />
          <span>Monitoring Density vs Pollution Severity Distinction</span>
        </div>
        <p className="leading-relaxed text-[11px]">
          A state having more monitoring stations or observations does not automatically imply it is more polluted. High-density monitoring frequently reflects active state pollution control programs and targeted surveillance of urbanized stretches.
        </p>
      </div>
    </div>
  );
};
