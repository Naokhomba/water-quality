import React from 'react';
import { Droplets, ExternalLink, ShieldCheck, Database, FileText } from 'lucide-react';
import { ActiveTab } from '../../types';

interface FooterProps {
  setActiveTab: (tab: ActiveTab) => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab }) => {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 text-xs mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Col 1 */}
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <div className="w-7 h-7 rounded-lg bg-cyan-600 flex items-center justify-center">
                <Droplets className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold text-white tracking-tight">INDIA WATER MONITOR</span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed">
              Explore, Compare and Understand Water Quality Across India. An independent environmental intelligence platform tracking public water monitoring records.
            </p>
            <div className="flex items-center space-x-2 text-[11px] text-cyan-400">
              <ShieldCheck className="w-4 h-4" />
              <span>Zero fabricated values • 100% Provenance Traceable</span>
            </div>
          </div>

          {/* Col 2 */}
          <div className="space-y-2">
            <h4 className="text-white font-semibold text-xs tracking-wider uppercase">Data Sources</h4>
            <ul className="space-y-1.5 text-xs">
              <li>
                <a href="https://waterdatagroup.com" target="_blank" rel="noreferrer" className="hover:text-cyan-400 flex items-center space-x-1">
                  <span>Water Data Group Directory</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a href="https://cpcb.nic.in/nwmp-data/" target="_blank" rel="noreferrer" className="hover:text-cyan-400 flex items-center space-x-1">
                  <span>CPCB NWMP Water Quality Portal</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a href="https://cwc.gov.in" target="_blank" rel="noreferrer" className="hover:text-cyan-400 flex items-center space-x-1">
                  <span>Central Water Commission (CWC)</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a href="https://nwdp.nwic.in" target="_blank" rel="noreferrer" className="hover:text-cyan-400 flex items-center space-x-1">
                  <span>National Water Data Portal (NWDP)</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a href="https://aikosh.indiaai.gov.in" target="_blank" rel="noreferrer" className="hover:text-cyan-400 flex items-center space-x-1">
                  <span>AI-KOSH Open Government Data</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3 */}
          <div className="space-y-2">
            <h4 className="text-white font-semibold text-xs tracking-wider uppercase">Navigation & Guides</h4>
            <ul className="space-y-1.5 text-xs">
              <li><button onClick={() => setActiveTab('map')} className="hover:text-cyan-400">Interactive India Map</button></li>
              <li><button onClick={() => setActiveTab('rivers')} className="hover:text-cyan-400">River Quality Explorer</button></li>
              <li><button onClick={() => setActiveTab('compare')} className="hover:text-cyan-400">State Comparison Tool</button></li>
              <li><button onClick={() => setActiveTab('parameters')} className="hover:text-cyan-400">Parameter Guide (BOD, DO, pH)</button></li>
              <li><button onClick={() => setActiveTab('explorer')} className="hover:text-cyan-400">Raw Data Explorer & CSV Export</button></li>
              <li><button onClick={() => setActiveTab('methodology')} className="hover:text-cyan-400">Scientific Methodology & Formulas</button></li>
            </ul>
          </div>

          {/* Col 4 */}
          <div className="space-y-2">
            <h4 className="text-white font-semibold text-xs tracking-wider uppercase">Target Audience</h4>
            <p className="text-slate-400 text-xs leading-relaxed">
              Designed for environmental and civil engineering students, researchers, journalists, public policy analysts, and citizens seeking verified water environmental intelligence.
            </p>
            <div className="pt-2">
              <span className="text-[11px] bg-slate-900 px-2.5 py-1 rounded border border-slate-800 text-slate-300">
                Data Updated: 2025/2026 Directory
              </span>
            </div>
          </div>
        </div>

        {/* Legal Disclaimer Box */}
        <div className="bg-slate-900/60 rounded-xl p-4 border border-slate-800/80 mb-6 text-slate-400 text-[11px] leading-relaxed">
          <span className="font-semibold text-slate-200">Official Disclaimer: </span>
          Data displayed on this platform is derived from publicly available datasets and is presented for information, education, and analytical purposes. The dashboard does not replace official environmental monitoring, regulatory classifications, or government advisories. Differences in sampling frequency, locations, parameters, and data availability can affect comparisons between states and locations.
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between text-slate-500 text-[11px] pt-4 border-t border-slate-900">
          <div>
            © {new Date().getFullYear()} India Water Pollution & Water Quality Monitor. Built for educational, analytical, and public-awareness purposes.
          </div>
          <div className="flex items-center space-x-4 mt-2 sm:mt-0">
            <button onClick={() => setActiveTab('methodology')} className="hover:text-slate-400">Methodology</button>
            <button onClick={() => setActiveTab('about')} className="hover:text-slate-400">About Project</button>
            <a href="https://waterdatagroup.com" target="_blank" rel="noreferrer" className="hover:text-slate-400 flex items-center space-x-1">
              <span>Water Data Group</span>
              <ExternalLink className="w-2.5 h-2.5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
