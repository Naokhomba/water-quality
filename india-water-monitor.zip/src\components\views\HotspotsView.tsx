import React, { useState } from 'react';
import { StateSummary } from '../../types';
import { Flame, AlertTriangle, ShieldCheck, Filter } from 'lucide-react';

interface HotspotsViewProps {
  states: StateSummary[];
  onSelectState: (state: string) => void;
}

export const HotspotsView: React.FC<HotspotsViewProps> = ({ states, onSelectState }) => {
  const [filterType, setFilterType] = useState<'BOD' | 'DO' | 'Conductivity'>('BOD');

  // Sort states based on filter
  const sortedStates = React.useMemo(() => {
    const list = states.filter(s => s.parameters[filterType] && s.parameters[filterType].latest !== undefined);
    if (filterType === 'BOD' || filterType === 'Conductivity') {
      return list.sort((a, b) => (b.parameters[filterType]?.latest ?? 0) - (a.parameters[filterType]?.latest ?? 0));
    } else {
      // DO: lowest is worse
      return list.sort((a, b) => (a.parameters[filterType]?.latest ?? 99) - (b.parameters[filterType]?.latest ?? 99));
    }
  }, [states, filterType]);

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="pb-4 border-b border-slate-800">
        <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center space-x-2">
          <Flame className="w-6 h-6 text-rose-500 animate-pulse" />
          <span>Pollution Screening & Priority Hotspots</span>
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Percentile-based screening identifying areas with unusually high organic loads or depressed dissolved oxygen.
        </p>
      </div>

      {/* Mandatory Methodology Disclaimer Alert */}
      <div className="p-4 bg-amber-950/40 border border-amber-800/80 rounded-2xl text-xs text-amber-200 leading-relaxed flex items-start space-x-3">
        <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
        <div>
          <span className="font-bold text-white block mb-1">Methodology Notice:</span>
          Hotspot classification is based on selected parameter thresholds or percentile-based screening and should not be interpreted as an official government classification. A location having higher measurements often corresponds to dedicated surveillance of known industrialized points.
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center space-x-2 bg-slate-900 p-2 rounded-xl border border-slate-800 w-fit">
        <button
          onClick={() => setFilterType('BOD')}
          className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${
            filterType === 'BOD' ? 'bg-rose-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          Highest BOD Locations
        </button>
        <button
          onClick={() => setFilterType('DO')}
          className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${
            filterType === 'DO' ? 'bg-amber-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          Lowest Dissolved Oxygen Locations
        </button>
        <button
          onClick={() => setFilterType('Conductivity')}
          className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${
            filterType === 'Conductivity' ? 'bg-cyan-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
          }`}
        >
          Highest Mineral / Conductivity
        </button>
      </div>

      {/* List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {sortedStates.slice(0, 12).map((s, idx) => {
          const p = s.parameters[filterType];
          return (
            <div
              key={s.state}
              onClick={() => onSelectState(s.state)}
              className="bg-slate-900 border border-slate-800 hover:border-rose-700/60 rounded-2xl p-5 shadow-xl cursor-pointer transition-all hover:shadow-2xl group"
            >
              <div className="flex justify-between items-start mb-2">
                <span className="w-6 h-6 rounded-full bg-slate-800 text-slate-300 font-bold text-xs flex items-center justify-center">
                  {idx + 1}
                </span>
                <span className="text-[10px] font-semibold text-rose-400 bg-rose-950 px-2 py-0.5 rounded border border-rose-800">
                  Priority Screening
                </span>
              </div>

              <h4 className="text-base font-bold text-white group-hover:text-rose-400 transition-colors">
                {s.state}
              </h4>
              <p className="text-xs text-slate-400 mb-3">
                {s.stationCount} monitoring stations • {s.rivers.slice(0, 2).join(', ')}
              </p>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex justify-between items-center text-xs">
                <span className="text-slate-400">{filterType}:</span>
                <span className="font-mono font-bold text-rose-300 text-sm">
                  {p?.latest} {p?.unit}
                </span>
              </div>

              <div className="mt-3 flex justify-between text-[11px] text-slate-500">
                <span>Historical Avg: {p?.avg} {p?.unit}</span>
                <span className="text-cyan-400 font-medium">Inspect →</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
